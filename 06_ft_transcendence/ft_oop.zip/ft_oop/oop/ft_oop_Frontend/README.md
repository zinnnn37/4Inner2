# ft_Oop

<img src="https://avatars.githubusercontent.com/u/156639997?s=200&v=4" width="150x;" alt=""/>

Oop(웁) 프로젝트는 "퐁(Pong)"이라는 1972년에 ATARI에서 처음으로 출시된 비디오 게임을 모티브로 제작한 게임 웹사이트 입니다. </br>
추가적으로 숨을 참는 스킬을 가미하여 제작하였습니다. </br>
</br>


<img src="https://img.shields.io/github/repo-size/ft-oop/ft_oop_Frontend?&style=flat-square">

</br>

## 👩🏻‍💻 Developer
<table>
  <tr>
    <th align="center"><a href="https://github.com/zinnnn37"><img src="https://avatars.githubusercontent.com/u/102711874?v=4" width="150x;" alt=""/><br /></a></th>
    <th align="center"><a href="https://github.com/oio337a"><img src="https://avatars.githubusercontent.com/u/75519420?v=4" width="150x;" alt=""/><br /></a></th>
    <th align="center"><a href="https://github.com/gnsals64"><img src="https://avatars.githubusercontent.com/u/50704029?v=4" width="150px;" alt=""/><br /></a></th>
  </tr>
  <tr>  
    <th><a href="https://github.com/zinnnn37"><b>김민진</b></a></th>
    <th><a href="https://github.com/oio337a"><b>박용민</b></a></th>
    <th><a href="https://github.com/gnsals64"><b>박훈민</b></a></th>
  </tr>
</table>


## 🛠 Tech Stack
<a href="#">
  <img src="https://img.shields.io/badge/logo-javascript-blue?logo=javascript">
</a>


</br>

## 🧱 Project Structure

```📦 dnd-7th-3-frontend
 ┣ 📂 .github
 ┣ 📂 public
 ┣ 📂 src
 ┃ ┣ 📂 component
 ┃ ┣ 📂 constant
 ┃ ┣ 📂 core
 ┃ ┣ 📂 style
 ┃ ┣ 📂 utils
 ┃ ┣ 📜 app.js
 ┃ ┣ 📜 global.js
 ┃ ┣ 📜 router.js
 ┣ 📜 .gitignore
 ┣ 📜 .eslintrc.json
 ┣ 📜 .prettierrc.json
 ┣ 📜 index.html
 ┣ 📜 main.js
 ┣ 📜 package.json
 ┣ 📜 package-lock.json
 ┣ 📜 tailwind.config.js
 ┣ 📜 vite.config.js
 ┣ 📜 README.md
 ┣ 📜 LICENSE
```

## ****📚****  Documentations

- [WORKSPACE](https://curvy-owl-b6d.notion.site/ft-Oop-f9582b0b4f4b4f1fb74022bb5b8a51cb?pvs=4)
- [PPT]()


