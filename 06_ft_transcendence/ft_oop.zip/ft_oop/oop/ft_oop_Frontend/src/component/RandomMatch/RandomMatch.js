import Component from '../../core/Component.js';
import { socket } from '../../utils/socket.js';
import GameRoom from '../GameRoom/GameRoom.js';
import { $ } from '../../utils/querySelector.js';

export default class RandomMatch extends Component {
  setup() {
    this.socketMessage();
    this.setEvent();
    this.render();
  }
  socketMessage() {
    if (socket.readyState === WebSocket.OPEN) {
      socket.send(
        JSON.stringify({
          message: 'random_match',
          name: this.props.username,
        }),
      );
    }

    socket.onmessage = (e) => {
      const data = JSON.parse(e.data);
      if (data.type === 'enter_room') {
        new GameRoom(
          $('#app'),
          data.room_id,
          0,
          undefined,
          this.props.username,
        );
      }
    };
  }

  template() {
    return `
      <div class='fixed top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-white rounded-3xl shadow-2xl flex flex-col justify-center items-center gap-6'>
        <img src="../../../public/eva--arrow-back-fill.svg" alt="close" id="goBackRandomMatch" class='h-8 absolute top-6 left-6 rounded-full p-1 hover:shadow-md cursor-pointer'/>
        <div class='text-xl font-bold'>
          <span class='text-4xl mr-2'>🤝</span>1:1 랜덤 매칭
        </div>
        <img alt='logo' src='../../../public/logo.png' class=' h-[150px]' /> 
        <div class='animate-pulse text-lg font-semibold text-gray-700'>
          상대를 찾을 때까지 숨참는 중...
        </div>
      </div>
    `;
  }
  setEvent() {
    this.addEvent('click', '#goBackRandomMatch', (e) => {
      if (socket.readyState === WebSocket.OPEN) {
        socket.send(
          JSON.stringify({
            message: 'random_match_cancel',
            name: this.props.username,
          }),
        );
      }
      this.$target.remove();
    });
  }
}
