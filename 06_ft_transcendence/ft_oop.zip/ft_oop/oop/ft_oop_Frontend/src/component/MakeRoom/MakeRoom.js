import Component from '../../core/Component.js';
import { $ } from '../../utils/querySelector.js';
import apiController from '../../utils/apiController.js';
import GameRoom from '../GameRoom/GameRoom.js';
import Tournament from '../GameRoom/Tournament.js';

export default class MakeRoom extends Component {
  template() {
    return `
      <form id="makeRoomForm">
      <div class='bg-white w-[500px] h-[600px] rounded-xl shadow-lg flex flex-col justify-between items-center'>
        <div class='ml-2 mt-2 self-start'>
          <span class='text-5xl'>🏡</span>
          <span class='text-2xl font-bold'>방 만들기</span>
        </div>
        <div class='flex flex-col justify-center items-center w-2/3 flex-1 space-y-8 drop-shadow'>
        <div class="input-group">
          <span class="input-group-text w-20 flex justify-center font-medium rounded-r-none">이름</span>
          <input type="text" class="form-control" id="roomName" placeholder="회원님의 방" aria-label="NickName" aria-describedby="input_nickname" required maxlength="15">
        </div>
        <div class="input-group w-full flex ">
          <label class="input-group-text w-20 flex justify-center font-medium rounded-r-none" for="inputGroupSelect01">타입</label>
          <select class="form-select flex-1 border px-[10px]" id="inputGroupSelect01" aria-label="Default select example" required>
            <option disabled selected value="">선택하세요</option>
            <option value="DUAL">1:1 대전</option>
            <option value="TOURNAMENT">토너먼트</option>
          </select>
        </div>
        <div class="w-full flex flex-col">
          <div class="input-group">
            <span class="input-group-text w-20 flex justify-center font-medium rounded-r-none">닉네임</span>
            <input id="nickNameInputBox" type="text" class="form-control disabled:bg-[#f7f7f7]" placeholder="토너먼트 닉네임" aria-label="NickName" aria-describedby="input_nickname" disabled>
          </div>
        </div>
        <div class="w-full flex flex-col">
          <div class="input-group">
            <span class="input-group-text w-20 flex justify-center font-medium rounded-r-none">비밀번호</span>
            <input id="passwordInputBox" type="text" pattern="[0-9]+" class="form-control invalid:border-red-500" placeholder="비밀방 원하면 입력해" aria-label="NickName" aria-describedby="input_nickname" maxlength="8">
          </div>
          <span class="mt-[5px] ml-20 flex text-sm">
            비밀번호는 숫자로만 입력해주세요.
          </span>
        </div>
        </div>
        <div class='mb-10 space-x-8'>
          <button type="button" id='cancelBtn' class="btn btn-secondary bg-gray-500 px-5 py-2">취소</button>
          <button type="button" id='confirmBtn' class="btn btn-primary bg-blue-500 px-5 py-2">확인</button>
        </div>
        <input type="text" style="display:none;">${
          /* submit 시 새로고침 방지 */ ''
        }
      </div>
      </form>
    `;
  }

  mounted() {
    this.addEvent('click', '#cancelBtn', (e) => {
      this.$target.remove();
    });

    this.addEvent('click', '#confirmBtn', async (e) => {
      const roomLimits = $('#inputGroupSelect01').value === 'DUAL' ? 2 : 4;
      const gameType = $('#inputGroupSelect01').value;

      const nickName =
        $('#nickNameInputBox').value === '' ? '' : $('#nickNameInputBox').value;

      const config = {
        method: 'POST',
        url: '/game',
        data: {
          roomName: $('#roomName').value,
          gameType: gameType,
          roomLimits,
          password: $('#passwordInputBox').value || '',
          nickname: nickName,
        },
      };

      try {
        const res = await apiController(config);
        this.$target.remove();

        if (res.data.game_type === 'DUAL') {
          const gameRoomWrapper = document.createElement('div');
          gameRoomWrapper.id = 'gameRoomWrapper';

          $('#app').innerHTML = '';
          $('#app').appendChild(gameRoomWrapper);

          new GameRoom(gameRoomWrapper, res.data.room_id, 0);
        } else {
          new Tournament($('#app'), {
            id: res.data.room_id,
            nickName: nickName,
          });
        }
      } catch (e) {
        const data = { status: e.data.code, data: e.data };

        this.handleInvalidInputs(data);
      }
    });
  }

  handleInvalidInputs(data) {
    if (data.status === 3000) {
      const nickname = $('#nickNameInputBox');

      nickname.classList.add('bg-red-100');
      nickname.value = '';
      nickname.classList.add('placeholder:text-red-400');
      nickname.setAttribute('placeholder', '중복된 닉네임입니다.');
    } else {
      // 3001
      const roomName = $('#roomName');
      const select1 = $('#inputGroupSelect01');
      const nickName = $('#nickNameInputBox');

      if (roomName.value === '') {
        roomName.classList.add('bg-red-100');
      }
      if (select1.value === '') {
        select1.classList.add('bg-red-100');
      }
      if (select1.value === 'TOURNAMENT') {
        if (nickName.value === '') {
          nickName.classList.add('bg-red-100');
        }
      }
    }
  }

  setEvent() {
    this.addEvent('change', '#inputGroupSelect01', (e) => {
      $('#inputGroupSelect01').classList.remove('bg-red-100');

      if (e.target.value === 'DUAL') {
        $('#nickNameInputBox').setAttribute('disabled', true);
      } else if (e.target.value === 'TOURNAMENT') {
        $('#nickNameInputBox').removeAttribute('disabled', false);
      }
    });

    this.addEvent('change', '#roomName', (e) => {
      $('#roomName').classList.remove('bg-red-100');
    });

    this.addEvent('change', '#nickNameInputBox', (e) => {
      $('#nickNameInputBox').classList.remove('bg-red-100');
      $('#nickNameInputBox').classList.remove('placeholder:text-red-400');
      $('#nickNameInputBox').setAttribute('placeholder', '토너먼트 닉네임');
    });
  }

  checkValid() {
    const roomName = $('#roomName').value;
    const roomType = $('#inputGroupSelect01').value;

    if (!roomName || !roomType || roomType === 'TOURNAMENT') {
      return false;
    }
    return true;
  }
}
