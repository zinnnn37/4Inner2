import Component from '../../core/Component.js';
import { $ } from '../../utils/querySelector.js';
import Logo from '../../core/Logo.js';
import Category from './Category.js';
import { navigate } from '../../utils/navigate.js';
import MakeRoom from '../MakeRoom/MakeRoom.js';
import RandomMatch from '../RandomMatch/RandomMatch.js';
import apiController from '../../utils/apiController.js';
import { socket, initWebSocket } from '../../utils/socket.js';

export default class Home extends Component {
  async setup() {
    try {
      initWebSocket();
      this.getSocketMessage();
      this.state = await this.getUserInfo();
      this.setEvent();
      this.render();
    } catch (e) {
      // console.log(e);
    }
  }

  getSocketMessage() {
    if (socket.readyState === WebSocket.OPEN) {
      socket.send(
        JSON.stringify({
          message: 'login',
          token: localStorage.getItem('accessToken'),
        }),
      );
    }

    socket.onmessage = (e) => {
      const data = JSON.parse(e.data);
    };
  }

  async getUserInfo() {
    const config = {
      url: '/main',
    };

    const res = await apiController(config);
    const { data } = res;

    return data;
  }

  mounted() {
    const $category = document.createElement('div');
    const $info = document.createElement('div');

    $category.id = 'category';
    $category.className =
      'flex justify-center items-center w-full h-full gap-6';
    $category.innerHTML = `
    <div id='room-list'></div>
    <div id='make-room'></div>
    <div id='random-match'></div>
    `;
    $('#app').appendChild($category);

    $info.id = 'info';
    $info.className = '';
    $info.innerHTML = `
    <div id='info' class='absolute flex top-10 right-6 text-3xl font-bold items-center gap-2 cursor-pointer group'>
      <div class="w-10 h-10 rounded-full overflow-hidden shadow-md group-hover:w-11 group-hover:h-11">
        <img id='userAvatar' src="${this.state.picture}" alt="profile" class="w-[100%] h-[100%] object-cover">
      </div>
      <span class='underline decoration-indigo-500 decoration-solid underline-offset-3 decoration-2 font-semibold text-2xl group-hover:text-gray-500'>${this.state.username}</span>님
    </div>
    `;

    $('#app').appendChild($info);
    new Logo();
    new Category($('#room-list'), { title: '방 목록', emoji: '🗒️' });
    new Category($('#make-room'), { title: '방 만들기', emoji: '🏡' });
    new Category($('#random-match'), { title: '랜덤 매칭', emoji: '🤝' });
  }

  setEvent() {
    if ($('#app').classList.contains('HomeEvents')) return;
    $('#app').classList.add('HomeEvents');

    // 마이페이지 버튼 클릭 시 이벤트
    this.addEvent('click', '#info', (e) => {
      const targetURL = '/mypage';
      navigate(targetURL);
    });

    // 방만들기 버튼 클릭 시 이벤트
    this.addEvent('click', '#make-room', (e) => {
      const makeRoomModal = document.createElement('div');
      makeRoomModal.id = 'Modal_overlay';

      $('#app').appendChild(makeRoomModal);
      new MakeRoom(makeRoomModal);
    });

    // 랜덤매칭 버튼 클릭 시 이벤트
    this.addEvent('click', '#random-match', (e) => {
      const randomMatchModal = document.createElement('div');
      randomMatchModal.id = 'Modal_overlay';

      $('#app').appendChild(randomMatchModal);
      new RandomMatch(randomMatchModal, this.state);
    });

    // 방 목록 클릭 시 이벤트
    this.addEvent('click', '#room-list', (e) => {
      const targetURL = '/room-list';
      navigate(targetURL);
    });
  }
}
