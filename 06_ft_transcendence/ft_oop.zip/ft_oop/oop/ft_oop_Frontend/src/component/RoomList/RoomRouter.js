import Component from '../../core/Component.js';
import { $ } from '../../utils/querySelector.js';
import apiController from '../../utils/apiController.js';
import GameRoom from '../GameRoom/GameRoom.js';
import Tournament from '../GameRoom/Tournament.js';

export default class RoomRouter extends Component {
  template() {
    return `
      <div class='fixed top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-white rounded-3xl shadow-2xl flex flex-col justify-center items-center gap-6'>
        <img src="../../../public/eva--arrow-back-fill.svg" alt="close" id="goBackRoomRouter" class='h-8 absolute top-6 left-6 rounded-full p-1 hover:shadow-md cursor-pointer'/>
        <div class='text-xl font-bold'>
          <span class='text-4xl mr-2'>🖐</span>추가 정보 입력
        </div>
        <div id="roomRouterWarning" class="invisible text-red-500">잘못된 비밀번호입니다.</div>
        <div class="px-4">
          ${
            this.props.type === 1
              ? `<input type="text" class="form-control" id="nickNameInput" placeholder="닉네임" aria-label="NickName" aria-describedby="input_nickname"></input>`
              : ''
          }
          ${
            this.props.password
              ? `<input type="text" class="form-control" id="passwardInput" placeholder="비밀번호" aria-label="Passward" aria-describedby="input_passward">`
              : ''
          }
        </div>
        <button type="button" id='confirmBtn' class="btn btn-primary bg-blue-500 px-5 py-2">확인</button>
      </div>
    `;
  }

  mounted() {
    this.addEvent('click', '#goBackRoomRouter', (e) => {
      this.$target.remove();
    });

    this.addEvent('click', '#confirmBtn', async (e) => {
      const roomId = this.props.id;
      let nickName = '';
      let password = '';
      const roomType = this.props.type === 0 ? 'dual' : 'tournament';

      if (this.props.type === 1) {
        nickName = $('#nickNameInput').value;
      }
      if (this.props.password) {
        password = $('#passwardInput').value;
      }
      const config = {
        url: `/game/${this.props.type === 0 ? 'dual' : 'tournament'}/${roomId}`,
        params: {
          nickName: nickName ? nickName : '',
          password: password ? password : '',
        },
      };

      try {
        const res = await apiController(config);

        if (roomType === 'dual') {
          new GameRoom($('#app'), roomId, 0);
        } else {
          new Tournament($('#app'), { id: roomId, nickName: nickName });
        }
      } catch (e) {
        const data = { status: e.data.code, data: e.data };

        this.handleError(data);
      }
    });
  }

  handleError(data) {
    const warning = $('#roomRouterWarning');

    if (data.status === 4001) {
      // console.log('invalid room type');
    } else if (data.status === 4002) {
      warning.innerHTML = '방이 가득 찼습니다.';
      warning.classList.remove('invisible');
    } else if (data.status === 4003) {
      warning.innerHTML = '비밀번호가 틀렸습니다.';
      warning.classList.remove('invisible');
    } else if (data.status === 4004) {
      warning.innerHTML = '중복된 닉네임입니다.';
      warning.classList.remove('invisible');
    } else if (data.status === 4005) {
      warning.innerHTML = '공백문자만 포함할 수 없습니다.';
      warning.classList.remove('invisible');
    } else {
      // console.log('error');
    }
  }
}
