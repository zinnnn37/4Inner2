import Component from '../../core/Component.js';
import Logo from '../../core/Logo.js';
import { $ } from '../../utils/querySelector.js';
import RoomListWrapper from './RoomListWrapper.js';
import { initWebSocket, socket } from '../../utils/socket.js';
import { useState } from '../../utils/useState.js';
import { checkHeartbeat } from '../../utils/socket.js';
import { navigate } from '../../utils/navigate.js';

export default class RoomList extends Component {
  setup() {
    this.checkPath();
    initWebSocket();

    this.setEvent();
    this.render();
  }

  checkPath() {
    if (window.location.pathname !== '/room-list') {
      history.pushState(null, null, `/room-list`);
    }
  }

  mounted() {
    const [getRoomListCheck, setGetRoomListCheck] = useState(
      'roomListCheck',
      false,
    );
    const [roomList, setRoomList] = useState('roomList', []);

    this.props = {
      getRoomListCheck,
      setGetRoomListCheck,
      roomList,
      setRoomList,
    };

    if (socket.readyState === WebSocket.OPEN && !getRoomListCheck) {
      socket.send(JSON.stringify({ message: 'getRoomList' }));
      setGetRoomListCheck(true);
    }

    socket.onmessage = (e) => {
      if (!checkHeartbeat(e)) {
        const data = JSON.parse(e.data);

        setRoomList(data);
      }
    };

    const $roomList = document.createElement('div');
    $roomList.id = 'room-lists';
    $roomList.className =
      'overflow-y-auto fixed top-1/2 left-1/2 transform -translate-x-1/2 flex justify-center items-center -translate-y-1/2 bg-white w-2/3 h-3/4 shadow-lg rounded-3xl';

    $('#app').appendChild($roomList);
    new Logo();
    new RoomListWrapper($roomList, { roomList, setGetRoomListCheck });
  }

  setEvent() {
    if ($('#app').classList.contains('RoomListWrapperEvents')) return;
    $('#app').classList.add('RoomListWrapperEvents');

    this.addEvent('click', '#goBack', (e) => {
      this.props.setGetRoomListCheck(false);
      navigate('/');
    });
  }
}
