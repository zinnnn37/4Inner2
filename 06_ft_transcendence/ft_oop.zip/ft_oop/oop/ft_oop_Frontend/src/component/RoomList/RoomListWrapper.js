import Component from '../../core/Component.js';
import { $ } from '../../utils/querySelector.js';
import RoomListDetail from './RoomListDetail.js';
import { navigate } from '../../utils/navigate.js';

export default class RoomListWrapper extends Component {
  template() {
    return `
      <div class='w-full h-[80%] flex flex-col justify-start items-center'>
        <img id='goBack' src="../../../public/eva--arrow-back-fill.svg" alt="close" class='h-8 absolute top-6 left-6 rounded-full p-1 hover:shadow-md cursor-pointer'/>
        <div class='text-3xl font-bold mb-4'>
          <span class='text-4xl mr-2'>🗒</span>방 목록
        </div>
        <div id='room-list-detail' class='w-full max-h-[900px] pb-[10px] h-[calc((${this.props.roomList.length} * 100)px + 100px)] overflow-y-scroll px-6 grid grid-cols-2 gap-3'></div>
      </div>
    `;
  }

  mounted() {
    // 소켓으로 방 정보 받아오기.
    new RoomListDetail($('#room-list-detail'), this.props.roomList);
  }
}
