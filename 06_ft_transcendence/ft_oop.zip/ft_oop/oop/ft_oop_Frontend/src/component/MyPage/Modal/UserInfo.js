import Component from "../../../core/Component.js";
import apiController from "../../../utils/apiController.js";
import Profile from "../Profile.js";
import HistoryTable from "../Table/HistoryTable.js";
import UserTable from "../Table/UserTable.js";
import { tableNumbers } from "../../../constant/tableNumbers.js";
import { $ } from "../../../utils/querySelector.js";

export default class UserInfo extends Component {
  constructor($target, props) {
    super($target, props);

    this.icon1 = "";
    this.icon2 = "";
  }

  async setup() {
    this.state = await this.getUserInfo();

    this.setProfileIcons();
    this.setEvent();
    this.render();
  }

  async getUserInfo() {
    const config = {
      url: "/users/info",
      params: {
        userID: this.props.id,
      },
    };

    const res = await apiController(config);
    const { data } = res;

    return data;
  }

  setProfileIcons() {
    if (this.state.is_block) {
      this.icon1 = "";
      this.icon2 = "../../../public/unblock.svg";
    } else if (this.state.is_friend) {
      this.icon1 = "../../../public/delete_friend.svg";
      this.icon2 = "../../../public/block.svg";
    } else {
      this.icon1 = "../../../public/add_friend.svg";
      this.icon2 = "../../../public/block.svg";
    }
  }

  template() {
    return `
      <div class="w-[800px] h-[800px] relative justify-center
        bg-white rounded-[30px] flex-col p-[50px]">
        <img src="../../../../public/eva--close-fill.svg" alt="icon close" id="modal_close"
          class="absolute top-[20px] right-[20px] w-[40px] h-[40px] cursor-pointer"
        />
        <div id="user_info_container"
          class="w-[100%] h-[100%]"
        >
        </div>
      </div>
    `;
  }

  mounted() {
    const information = this.$target.querySelector("#user_info_container");
    const profile = document.createElement("div");
    profile.id = "user_info_profile";

    this.setUserInfoContainer(profile);
    this.setUserInfoProfile(profile);

    information.appendChild(profile);

    // if ($('#Friend_table')) {
    //   new Profile(profile, this.state, '/delete_friend.svg', '/block.svg');
    // } else if ($('#Block_table')) {
    //   new Profile(profile, this.state, '', '/block.svg');
    // }
    new Profile(profile, {
      state: this.state,
      icon1: this.icon1,
      icon2: this.icon2,
    });

    // tables
    const userHistoryTable = document.createElement("div");
    userHistoryTable.id = "user_info_history";

    this.setUserHistoryTable(userHistoryTable);

    information.appendChild(userHistoryTable);

    new HistoryTable(userHistoryTable, this.props);
  }

  setEvent() {
    this.addEvent("click", "#modal_close", () => {
      new UserTable(
        $("#MyPage_info__user_list"),
        "친구 목록",
        tableNumbers.FRIEND,
        this.props
      );
      this.$target.remove();
    });

    // 친구 추가
    this.addEvent("click", "#icon_add_friend", async (e) => {
      const config = {
        url: "/friend/add",
        method: "POST",
        data: {
          friend: this.props.name,
        },
      };

      const res = await apiController(config);

      if (res.status === 200) {
        new UserInfo(this.$target, this.props);
      }
    });

    // 친구 삭제
    this.addEvent("click", "#icon_delete_friend", async (e) => {
      const config = {
        method: "POST",
        url: "/friend/delete",
        data: {
          friendName: this.props.name,
        },
      };

      const res = await apiController(config);

      if (res.status === 200) {
        new UserInfo(this.$target, this.props);
      }
    });

    // 친구 차단
    this.addEvent("click", "#icon_block", async (e) => {
      const config = {
        method: "POST",
        url: "/friend/ban-list/add",
        data: {
          userName: this.props.myname,
          blockName: this.props.name,
        },
      };

      const res = await apiController(config);

      if (res.status === 200) {
        new UserInfo(this.$target, this.props);
      }
    });

    // 친구 차단 해제
    this.addEvent("click", "#icon_unblock", async (e) => {
      const config = {
        method: "POST",
        url: "/friend/ban-list/delete",
        data: {
          userName: this.props.myname,
          blockName: this.props.name,
        },
      };

      const res = await apiController(config);

      if (res.status === 200) {
        new UserInfo(this.$target, this.props);
      }
    });
  }

  setUserInfoContainer(info) {
    info.style.width = "100%";
    info.style.height = "100%";

    info.style.flexDirection = "column";
    info.style.justifyContent = "center";
    info.style.alignItems = "center";
  }

  setUserInfoProfile(profile) {
    profile.style.width = "100%";
    profile.style.height = "200px";

    profile.style["padding-left"] = "50px";
    profile.style["padding-right"] = "50px";

    profile.style.display = "flex";
    profile.style.flexDirection = "row";
    profile.style.justifyContent = "center";
    profile.style.alignItems = "center";
  }

  setUserHistoryTable(table) {
    table.style.width = "100%";
    table.style.height = "500px";

    table.style.display = "flex";
    table.style.overflow = "hidden";

    table.style.borderRadius = "30px";
    table.style.boxShadow = "5px 5px 10px 0px rgba(0, 0, 0, 0.2)";
  }
}
