import Component from "../../../core/Component.js";
import { setModalWrapper } from "../../../utils/setModalWrapper.js";
import { $ } from "../../../utils/querySelector.js";
import GameWait from "./GameWait.js";
import Chat from "./Chat.js";

export default class GameInvite extends Component {
  constructor($target, props, socket) {
    super($target, props);
    this.socket = socket;
    this.setup();
  }

  setup() {
    setModalWrapper(this.$target);

    this.setEvent();
    this.render();
  }

  template() {
    return `
      <div class="w-[400px] h-[200px] flex justify-center flex-col bg-white rounded-[30px] px-[40px]">
        <div class="h-[76px] pb-[20px] text-lg font-medium">
          게임 초대가 도착했습니다.
        </div>
        <div class="w-full h-[40px] flex flex-row-reverse">
            <button type="button" id="modal_invite_disagree" class="btn btn-primary px-[30px]">거절</button>
            <button type="button" id="game_invite_agree" class="btn btn-primary px-[30px]">수락</button>
        </div>
      </div>
    `;
  }

  sendMessage(message) {
    this.socket.send(
      JSON.stringify({
        receiver: this.props.friendID,
        sender: this.props.state.user_id,
        message,
      })
    );
  }

  setEvent() {
    if (this.$target.classList.contains("GameInvite")) return;
    this.$target.classList.add("GameInvite");

    this.$target.addEventListener("click", async (e) => {
      if (e.target.id === "modal_invite_disagree") {
        this.sendMessage("cancel_game_in_chat");
        new Chat(this.$target, this.props, this.socket);
      } else if (e.target.id === "game_invite_agree") {
        this.sendMessage("start_game_in_chat");
        new GameWait($("#app"), this.props, this.socket);
      }
    });
  }
}
