import Component from "../../../core/Component.js";
import apiController from "../../../utils/apiController.js";
import { $ } from "../../../utils/querySelector.js";
import { checkHeartbeat } from "../../../utils/socket.js";
import UserInfo from "./UserInfo.js";
import GameInvite from "./GameInvite.js";
import Alert from "./Alert.js";
import GameRoom from "../../GameRoom/GameRoom.js";
import { MAIN_WEBSOCKET } from "../../../global.js";

export default class Chat extends Component {
  constructor($target, props, socket) {
    super($target, props);
    this.chatSocket = socket;

    this.prevSender = "";
  }

  async setup() {
    const config = {
      url: "/mypage/chat",
      params: {
        receiver: this.props.friendID,
        sender: this.props.state.user_id,
      },
    };
    const res = await apiController(config);
    this.state = res.data;

    this.setSocket();
    this.socketMessage();
    this.setEvent();
    this.render();
    this.restoreAndAppendChatHistory();
    this.scrollToBottom();
  }

  setSocket() {
    const friendID = this.props.friendID;
    const userID = this.props.state.user_id;
    const socketUrl =
      userID > friendID ? `${userID}-${friendID}` : `${friendID}-${userID}`;

    if (!this.chatSocket || this.chatSocket === undefined) {
      this.chatSocket = new WebSocket(`${MAIN_WEBSOCKET}chat/${socketUrl}/`);
    }
  }

  socketMessage() {
    this.chatSocket.onmessage = (e) => {
      if (!checkHeartbeat(e)) {
        const data = JSON.parse(e.data);
        if (data.message === "invited") {
          new GameInvite(this.$target, this.props, this.chatSocket);
        } else if (data.message === "enter_room") {
          this.chatSocket.close();
          new GameRoom(
            $("#app"),
            data.room_id,
            0,
            undefined,
            this.props.state.username
          );
        }
        if (data.sender !== undefined) {
          if (data.sender === this.props.state.user_id) {
            this.appendSentChat(data.message);
          } else {
            this.appendReceivedChat(data.message, data.sender, this.prevSender);
            this.prevSender = data.sender;
          }
        }
      }
    };
  }

  // 내가 보낸 메시지 추가
  appendSentChat(data) {
    const chatContent = $("#app").querySelector("#chat_content");
    const chat = document.createElement("div");
    chat.class = "sent_chat_bubble";

    this.setMyChatBubbleStyle(chat, data);
    chatContent.appendChild(chat);

    this.scrollToBottom();

    const closest = chat.previousElementSibling;

    // 마지막 버블만 뾰족하게
    if (closest && closest.class === "sent_chat_bubble") {
      closest.style.borderBottomRightRadius = "20px";
    }
  }

  // 상대방이 보낸 메시지 추가
  appendReceivedChat(data, sender, prevSender) {
    const chatContent = this.$target.querySelector("#chat_content");
    const chatWrapper = document.createElement("div");
    const avatar = document.createElement("div");
    const chat = document.createElement("div");

    chatWrapper.classList.add("flex", "items-end");
    avatar.classList.add(
      "w-[30px]",
      "h-[30px]",
      "mr-[10px]",
      "bottom-0",
      "left-0"
    );

    avatar.innerHTML = `
      <div class="w-[30px] h-[30px] rounded-full overflow-hidden">
        <img class="chatAvatar cursor-pointer w-[100%] h-[100%] object-cover" src="${this.state.receiver_picture}" alt="profile">
      </div>`;

    chat.class = "received_chat_bubble";

    this.setReceivedChatBubbleStyle(chat, data);

    chatWrapper.appendChild(avatar);
    chatWrapper.appendChild(chat);
    chatContent.appendChild(chatWrapper);

    this.scrollToBottom();

    const closestBubble = chat.parentNode.previousSibling.lastChild; // 이전 버블
    const closestAvatar = chat.parentNode.previousSibling.firstChild; // 이전 아바타

    // 마지막 버블만~~
    if (
      closestBubble &&
      closestBubble.class === "received_chat_bubble" &&
      sender === prevSender
    ) {
      closestBubble.style.borderBottomLeftRadius = "20px";
      closestAvatar.classList.add("invisible");
    }
  }

  template() {
    return `
      <div id="chat_wrapper" class="w-[800px] h-[800px] relative justify-center
        bg-white rounded-[30px] flex-col px-[30px] py-[20px]">
        <div class="w-full h-full flex-col justify-center">
          <div class="w-100% h-[50px] mb-[10px] flex justify-center items-center">
            <span class="w-[720px] text-center text-[24px] font-bold">${
              this.props.friendName
            }</span>
            <img src="../../../../public/game.svg" alt="icon game" id="chat_game"
              class="cursor-pointer mx-[10px]">
            <img src="../../../../public/eva--close-fill.svg" alt="icon close" id="chat_modal_close"
              class="cursor-pointer"/>
          </div>
          <div id="chat_content_wrapper"
            class="w-full h-[630px] mb-[10px] overflow-y-auto"
          >
            <div id="chat_content" class="w-full min-h-[630px] flex flex-col justify-end">
              ${"" /*this.restoreChatHistory()*/}
            </div>
          </div>
          <div class="w-full h-[60px] flex justify-center items-center">
            <input type="text" id="chat_input" class="w-full h-[40px] px-[15px] mr-[8px] rounded-[20px]
              focus:outline-none bg-[#e7eff8]"/>
            <img src="../../../../public/bubble.png" alt="icon send" id="chat_send" class="w-[52px] h-[52px] cursor-pointer"/>
          </div>
        </div>
      </div>
    `;
  }

  sendMessage(message) {
    if (message === "/invite") {
      this.gameInviteMessage(message);
    } else {
      this.chatSocket.send(
        JSON.stringify({
          receiver: this.props.friendID,
          sender: this.props.state.user_id,
          message: message,
        })
      );
    }
  }

  setEvent() {
    if (this.$target.classList.contains("chatEvent")) return;
    this.$target.classList.add("chatEvent");

    this.$target.addEventListener("keydown", (e) => {
      if (e.key === "Enter" && e.target.id === "chat_input") {
        if (e.isComposing) return;
        if (e.target.value === "") return;
        this.sendMessage(e.target.value);

        e.target.value = "";
        e.target.focus();
      }
    });

    this.$target.addEventListener("click", (e) => {
      if (e.target.id === "chat_send") {
        const chatInput = $("#chat_input");
        if (chatInput.value === "") return;
        this.sendMessage(chatInput.value);
        chatInput.value = "";
        chatInput.focus();

        // 채팅 종료
      } else if (e.target.id === "chat_modal_close") {
        this.chatSocket.close();
        this.$target.remove();

        // 사용자 아바타 클릭
      } else if (e.target.classList.contains("chatAvatar")) {
        this.appendUserInfoModal();

        // 사용자 정보 모달 닫기
      } else if (e.target.id === "modal_close") {
        $("#Modal_overlay").remove();
      } else if (e.target.id === "chat_game") {
        this.gameInviteMessage("/invite");
      }
    });
  }

  appendUserInfoModal() {
    const modal = document.createElement("div");
    modal.id = "Modal_overlay";

    $("#app").appendChild(modal);

    new UserInfo(modal, {
      id: this.props.friendID,
      name: this.props.friendName,
    });
  }

  scrollToBottom() {
    const chatContentWrapper = $("#chat_content_wrapper");
    chatContentWrapper.scrollTo(0, chatContentWrapper.scrollHeight);

    $("#chat_input").focus();
  }

  restoreAndAppendChatHistory() {
    const chatHistory = this.state.message_list;

    if (chatHistory) {
      chatHistory.forEach(
        ({ sender_id, reciever_id, message, timestamp }, index, arr) => {
          // 내가 보낸 메시지일 때
          if (sender_id === this.props.state.user_id) {
            this.appendSentChat(message);
          } else {
            // 상대방이 보낸 메시지일 때
            const prevSender = index === 0 ? "" : arr[index - 1].sender_id;
            this.appendReceivedChat(message, sender_id, prevSender);
          }
        }
      );
    }
  }

  gameInviteMessage(message) {
    const modal = document.createElement("div");
    modal.id = "Modal_overlay";

    this.$target.appendChild(modal);

    this.chatSocket.send(
      JSON.stringify({
        receiver: this.props.friendID,
        sender: this.props.state.user_id,
        message,
      })
    );
    new Alert(modal, { message: "📮 게임 초대 메세지를 보냈습니다 📮" });
  }

  setMyChatBubbleStyle(chat, message) {
    chat.style.width = "fit-content";
    chat.style.height = "fit-content";
    chat.style.maxWidth = "60%";
    chat.style.padding = "10px";
    chat.style.paddingLeft = "20px";
    chat.style.paddingRight = "20px";
    chat.style.borderRadius = "20px";
    chat.style.borderBottomRightRadius = "0px";
    chat.style.backgroundColor = "#ABC2EF";
    chat.style.marginBottom = "2px";
    chat.style.marginLeft = "auto";

    chat.style.overflowWrap = "break-word";
    chat.textContent = message;
  }

  setReceivedChatBubbleStyle(chat, message) {
    chat.style.width = "fit-content";
    chat.style.height = "fit-content";
    chat.style.maxWidth = "60%";
    chat.style.padding = "10px";
    chat.style.paddingLeft = "20px";
    chat.style.paddingRight = "20px";
    chat.style.borderRadius = "20px";
    chat.style.borderBottomLeftRadius = "0px";
    chat.style.backgroundColor = "#E7E7E7";
    chat.style.marginBottom = "2px";
    chat.style.marginRight = "auto";

    chat.style.overflowWrap = "break-word";
    chat.textContent = message;
  }
}
