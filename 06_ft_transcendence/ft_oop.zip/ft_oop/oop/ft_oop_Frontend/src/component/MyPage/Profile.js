import Component from '../../core/Component.js';

export default class Profile extends Component {
  constructor($target, props) {
    super($target, props);
  }

  setup() {
    this.setIconID();
    this.setEvent();
    this.render();
  }

  setIconID() {
    if (this.props.icon1 === '../../../public/add_friend.svg') {
      this.iconID1 = 'icon_add_friend';
    } else if (this.props.icon1 === '../../../public/delete_friend.svg') {
      this.iconID1 = 'icon_delete_friend';
    }

    if (this.props.icon2 === '../../../public/edit.svg') {
      this.iconID2 = 'edit_modal_open';
    } else if (this.props.icon2 === '../../../public/block.svg') {
      this.iconID2 = 'icon_block';
    } else if (this.props.icon2 === '../../../public/unblock.svg') {
      this.iconID2 = 'icon_unblock';
    }
  }

  template() {
    return `
    ${/* 전달받은 이미지로 경로 수정해야 함 */ ''}
      <div class="w-[100px] h-[100px] rounded-full overflow-hidden">
        <img id="mypage_avatar" src="${
          this.props.state.picture
        }" alt="profile" class="w-[100%] h-[100%] object-cover">
      </div>
      <div id="mypage_profile__wrapper">
        <div id="mypage_name">${this.props.state.username}</div>
        <div id="mypage_winlose">${this.props.state.total_win}승 ${
      this.props.state.total_lose
    }패</div>
      </div>
      ${this.props.icon1 ? this.createIcon1() : ''}
      <img id="${this.iconID2}" src="${
      this.props.icon2
    }" class="w-[40px] h-[40px] ml-[20px] cursor-pointer" alt="icon1">
    `;
  }

  createIcon1() {
    return `
      <img id="${this.iconID1}" src="${this.props.icon1}" class="w-[40px] h-[40px] ml-[20px] cursor-pointer" alt="icon1">
    `;
  }
}
