import Component from '../../../core/Component.js';
import { navigate } from '../../../utils/navigate.js';

export default class GameWait extends Component {
  constructor($target, props, d) {
    super($target, props);
    this.d = d;
    this.setup();
  }

  setup() {
    this.setEvent();
    this.render();
  }

  template() {
    return `
      <div class='fixed top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-white rounded-3xl shadow-2xl flex flex-col justify-center items-center gap-6'>
        <img src="../../../public/eva--arrow-back-fill.svg" alt="close" id="goBackGameWait" class='h-8 absolute top-6 left-6 rounded-full p-1 hover:shadow-md cursor-pointer'/>
        <div class='text-xl font-bold'>
          <span class='text-4xl mr-2'>🤼</span>${this.props.friendName}를 기다리는 중
        </div>
        <img alt='logo' src='../../../public/logo.png' class=' h-[150px]' /> 
        <div class='animate-pulse text-lg font-semibold text-gray-700'>
          상대가 수락할 때까지 숨참는 중...
        </div>
      </div>
    `;
  }

  setEvent() {
    this.addEvent('click', '#goBackGameWait', (e) => {
      this.d.send(
        JSON.stringify({
          receiver: this.props.friendID,
          sender: this.props.state.user_id,
          message: 'cancel_game_in_chat',
        }),
      );
      this.d.close();
      navigate('/mypage');
    });
  }
}
