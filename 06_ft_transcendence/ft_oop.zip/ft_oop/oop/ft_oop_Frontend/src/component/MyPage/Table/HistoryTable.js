import Component from '../../../core/Component.js';
import { $ } from '../../../utils/querySelector.js';
import apiController from '../../../utils/apiController.js';

export default class HistoryTable extends Component {
  async setup() {
    this.state = await this.getUserInfo();

    this.setEvent();
    this.render();
  }

  async getUserInfo() {
    const config = {
      url: '/users/info',
      params: {
        userID: this.props.id,
      },
    };
    const res = await apiController(config);
    const { data } = res;

    return data;
  }

  template() {
    return `
      <table class="MyPage__table">
        <caption>
          경기 기록
        </caption>
        <tbody class="TableBody">
          ${this.generateHistoryTable()}
        </tbody>
      </table>
    `;
  }

  mounted() {
    const tbody = this.$target.querySelector('.TableBody');

    if ($('#user_info_history')) {
      tbody.style.height = '410px';
    }

    tbody.innerHTML = this.generateHistoryTable();
  }

  generateHistoryTable() {
    const { match_history } = this.state;

    return match_history
      .map(
        (history) => `
      <tr class="History_table">
        <td class="history_date text-right px-[10px] ml-[20px] text-gray-500">${this.convertDate(
          history.match_date,
        )}</td>
        ${this.getOpponent(
          history.game_type,
          history.opponent_name,
          this.props.name,
        )}
        </td>
        <td class="history_result w-[70px] px-3 ml-[20px] mr-[30px] font-bold ${
          history.winner === this.props.name ? `text-cyan-400` : `text-red-300`
        }">${history.winner === this.props.name ? 'Win' : 'Lose'}</td>
      </tr>
    `,
      )
      .join('');
  }

  convertDate(date) {
    const splitDate = date.split('-');

    const year = splitDate[0][2] + splitDate[0][3];
    const month = splitDate[1];
    const day = splitDate[2];

    return `${year}${month}${day}`;
  }

  getOpponent(type, opponent, name = '') {
    if (type === '0') {
      return `
      <td class="w-full pr-[10px] text-right underline decoration-sky-500 text-gray-700">${name}</td>
      <td class="w-[30px] font-bold">vs</td>
      <td class="w-full pl-[10px] text-left underline decoration-sky-500 text-gray-700">${opponent}</td>
    `;
    } else {
      return `<td class="w-full">${opponent}</td>`;
    }
  }
}
