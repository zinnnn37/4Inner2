import Component from "../../../core/Component.js";
import { tableNumbers } from "../../../constant/tableNumbers.js";
import apiController from "../../../utils/apiController.js";
import { friendState } from "../MyPage.js";
import UserInfo from "../Modal/UserInfo.js";
import Chat from "../Modal/Chat.js";
import { $ } from "../../../utils/querySelector.js";
import Confirm from "../Modal/Confirm.js";

export default class UserTable extends Component {
  constructor($target, title, n, props) {
    super($target, props);

    this.title = title;
    this.n = n;
  }

  async setup() {
    this.state = await this.getUserInfo();

    this.setEvent();
    this.render();
  }

  async getUserInfo() {
    const config = {
      url: "/mypage",
    };
    const res = await apiController(config);
    const { data } = res;

    return data;
  }

  template() {
    const leftImage =
      this.n === tableNumbers.BLOCK
        ? "../../../../public/arrow-left-enabled.svg"
        : "../../../../public/arrow-left-disabled.svg";
    const rightImage =
      this.n === tableNumbers.BLOCK
        ? "../../../../public/arrow-right-disabled.svg"
        : "../../../../public/arrow-right-enabled.svg";

    const tableID =
      this.n === tableNumbers.BLOCK ? "Block_table" : "Friend_table";

    return `
      <table class="MyPage__table" id=${tableID}>
        <caption>
          <img src="${leftImage}" class="icon_left" id="icon_left${
      this.n
    }" alt="left-fill"></img>
          ${this.title}
          <img src="${rightImage}" class="icon_right" id="icon_right${
      this.n
    }" alt="right-fill"></img>
        </caption>
        <tbody>
          ${this.generateUserTable()}
        </tbody>
      </table>
    `;
  }

  generateUserTable() {
    const idName =
      this.n === tableNumbers.BLOCK ? "Block_table" : "Friend_table";
    const users =
      this.n === tableNumbers.BLOCK ? this.state.ban_list : this.state.friends;
    const display =
      this.n === tableNumbers.BLOCK ? "display: none" : "display: inline";
    const userNameClass =
      this.n === tableNumbers.BLOCK ? "block_name" : "friend_name";
    const userAvatarClass =
      this.n === tableNumbers.BLOCK ? "block_avatar" : "friend_avatar";

    return (
      users
        .map(
          (user) => `
      <tr class="${idName}">
        <td class="flex ml-[20px]">
          <div class="w-[40px] h-[40px] relative">
            ${/* Online: #60D395, Offline: #D3606E */ ""}
            ${
              this.n === tableNumbers.FRIEND
                ? `<div class="w-[10px] h-[10px] rounded-full bg-[${
                    friendState[user.user_name] === true ? "#60D395" : "#D3606E"
                  }] absolute right-0 bottom-0"></div>`
                : ""
            }
            ${/* Avatar */ ""}
            <div class="w-[40px] h-[40px] rounded-full overflow-hidden">
            ${/* 전달받은 이미지로 경로 수정해야 함 */ ""}  
              <img src="${user.picture}" alt="profile" id="user_avatar_${
            user.user_name
          }" class="${userAvatarClass} w-[100%] h-[100%] object-cover">
            </div>
          </div>
        </td>
        ${/* Name */ ""}
        <td id="user_name_${user.user_name}" class="${userNameClass}">${
            user.user_name
          }</td>
        ${/* DM */ ""}
        <td><img class="user_dm" src="../../../../public/eva--message-circle-fill.svg" style="${display}"></td>
        ${/* Delete */ ""}
        <td><img class="user_delete" src="../../../../public/eva--close-fill.svg"></td>
      </tr>
    `
        )
        .join("") +
      (this.n === tableNumbers.FRIEND
        ? `
          <tr id="addFriendInListWrapper" class="w-[100%]">
            <td id="addFrinedInList" class="flex flex-row w-[100%] h-[100%] justify-center items-center text-center cursor-pointer">
              <img src="/public/plus.svg" id="addFriendInListIcon" class="icon_plus flex" id="icon_plus" alt="plus"></img>
              <span id="addFriendInListText" class="flex ml-[4px] font-bold text-[#8090A8]">친구 추가</span>
            </td>
          </tr>
        `
        : "")
    );
  }

  setEvent() {
    if (this.$target.classList.contains("UserTableEvent")) return;

    this.$target.classList.add("UserTableEvent");

    this.$target.addEventListener("click", this.handleButtons.bind(this));
  }

  // handleButtons 메서드 정의
  handleButtons(e) {
    const target = e.target;
    if (
      target.classList.contains("icon_right") ||
      target.classList.contains("icon_left")
    ) {
      this.handleTables(target);
    } else if (
      target.classList.contains("friend_avatar") ||
      target.classList.contains("friend_name")
    ) {
      this.handleUser(target);
    } else if (target.classList.contains("user_dm")) {
      this.handleDM(target);
    } else if (target.classList.contains("user_delete")) {
      this.handleDelete(target);
    }
  }

  handleTables(button) {
    this.$target.removeEventListener("click", this.handleButtons.bind(this));

    if (this.$target.querySelector("#Friend_table")) {
      if (button.id === "icon_right1") {
        new UserTable(
          this.$target,
          "차단 목록",
          tableNumbers.BLOCK,
          this.props
        );
      }
    } else if (this.$target.querySelector("#Block_table")) {
      if (button.id === "icon_left2") {
        new UserTable(
          this.$target,
          "친구 목록",
          tableNumbers.FRIEND,
          this.props
        );
      }
    }
  }

  handleUser(button) {
    const userInfo = document.createElement("div");
    userInfo.id = "Modal_overlay";
    this.$target.appendChild(userInfo);

    const userName = button.id.includes("avatar")
      ? button.id.slice(12)
      : button.textContent;

    if (document.querySelector("#Friend_table")) {
      const friendID = this.findFriendID(userName);

      new UserInfo(userInfo, {
        id: friendID,
        name: userName,
        myname: this.props.username,
      });
    }
  }

  handleDM(button) {
    const chat = document.createElement("div");
    chat.id = "Modal_overlay_chat";

    this.$target.appendChild(chat);

    const friendName =
      button.parentNode.previousSibling.previousSibling.textContent;

    const friendID = this.findFriendID(friendName);

    new Chat(chat, { state: this.state, friendName, friendID }, null);
  }

  findFriendID(friendName) {
    for (let i = 0; i < this.state.friends.length; i++) {
      if (this.state.friends[i].user_name === friendName) {
        return this.state.friends[i].user_id;
      }
    }
  }

  handleDelete(button) {
    const confirm = document.createElement("div");
    confirm.id = "Modal_overlay";

    this.$target.appendChild(confirm);

    const friendToDelete =
      button.parentNode.previousSibling.previousSibling.previousSibling
        .previousSibling.textContent;

    if (document.querySelector("#Friend_table")) {
      new Confirm(confirm, "friend", this.props.username, friendToDelete);
    } else {
      new Confirm(confirm, "block", this.props.username, friendToDelete);
    }
  }
}
