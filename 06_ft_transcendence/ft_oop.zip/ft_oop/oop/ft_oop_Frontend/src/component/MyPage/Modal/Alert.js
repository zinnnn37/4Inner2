import Component from '../../../core/Component.js';
import { setModalWrapper } from '../../../utils/setModalWrapper.js';
import { $ } from '../../../utils/querySelector.js';
import { navigate } from '../../../utils/navigate.js';

export default class Alert extends Component {
  setup() {
    setModalWrapper(this.$target);

    this.setEvent();
    this.render();
    $('#modal_close').focus();
  }

  template() {
    return `
      <div class="w-[400px] h-[200px] flex justify-center flex-col bg-white rounded-[30px] px-[40px]">
        <div class="h-[76px] pb-[20px] text-lg font-medium">
          ${this.props.message}
        </div>
        <div class="w-full h-[40px] flex flex-row-reverse">
        <button type="button" id="modal_close" class="btn btn-primary px-[30px]">확인</button>
        </div>
      </div>
    `;
  }

  setEvent() {
    this.addEvent('click', '#modal_close', () => {
      this.$target.remove();

      if (this.props.path) {
        navigate(this.props.path);
      }
    });
  }
}
