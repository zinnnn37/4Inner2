import Component from '../../../core/Component.js';
import { $ } from '../../../utils/querySelector.js';
import Profile from '../Profile.js';
import apiController from '../../../utils/apiController.js';
import HistoryTable from '../Table/HistoryTable.js';

export default class Edit extends Component {
  constructor($target, props) {
    super($target, props);

    this.prevFileName = this.props.picture;
    this.newFileName = '';

    this.setup();
  }

  // this.props에 userName
  template() {
    return `
      <form name="editInfo" class="w-[500px] h-[300px] flex justify-center
        px-[40px] bg-white rounded-[30px] flex-col">
        <div class="w-full h-[194px] flex flex-col mb-2">
          ${this.createImageEdit()}
          ${this.createInputNickName()}
          <div id="duplicateWarning" class="px-[90px] text-red-500 hidden">중복된 이름입니다.</div>
        </div>
        <div class="w-full h-[40px] flex flex-row-reverse">
          ${this.createButtons()}
        </div>
      </form>
    `;
  }

  createImageEdit() {
    const fileName = $('#mypage_avatar').getAttribute('src');
    return `
    <div class="w-full h-[120px] flex">
      ${/* Image */ ''}
      <div class="relative w-[100px] h-[100px]">
        <div class="absolute w-full h-full rounded-full overflow-hidden">
          <div class="flex w-full h-full justify-center items-center">
            <img src="${fileName}" id="edit_modal_avatar" alt="user avatar" class="w-[100%] h-[100%] object-cover"/>
          </div>
        </div>
        ${/* Edit Icon */ ''}
        <div class="absolute w-full h-full bg-white opacity-70">
        <input type="file" id="avatar_upload" name="avatar_upload" style="display:none"
        accept="image/*"/>
          <img id="avatar_upload_entry" src="../../../../public/edit.svg" alt="edit icon" class="w-full p-[28px] cursor-pointer">
        </div>
      </div>
      ${/* Text */ ''}
      <div class="h-full flex grow flex-col justify-center ml-[20px]">
        <div class="text-2xl font-semibold">이미지 편집</div>
        <div class="text-lg mt-[8px]">최대 용량 1MB</div>
      </div>
    </div>`;
  }

  createInputNickName() {
    return `
      <div class="input-group mb-1">
        <span class="input-group-text" id="input_nickname">이름 입력</span>
        <input type="text" id="nickname_upload" class="form-control" placeholder="input name" aria-label="NickName" aria-describedby="input_nickname"  maxlength="15">
        <input type="text" style="display:none;">${
          /* submit 시 새로고침 방지 */ ''
        }
      </div>
    `;
  }

  createButtons() {
    return `
      <button id="edit_submit" type="button" class="btn btn-primary" style="background-color:#007bff; margin-left:8px; border-radius: 8px; padding-left:30px; padding-right:30px">확인</button>
      <button type="button" id="edit_modal_close" class="btn btn-secondary" style="background-color:#6c757d; border-radius: 8px; padding-left:30px; padding-right:30px">취소</button>
    `;
  }

  async setEvent() {
    if ($('#app').classList.contains('EditEvents')) return;
    this.$target.classList.add('EditEvents');

    // 프로필 수정 모달 닫기
    this.addEvent('click', '#edit_modal_close', (e) => {
      if (this.prevFileName !== $('#mypage_avatar').getAttribute('src')) {
        $('#mypage_avatar').setAttribute('src', this.prevFileName);
      }
      if (this.prefFileName !== this.newFileName) {
        this.newFileName = '';
      }
      this.$target.remove();
    });

    // 프로필 이미지 수정
    this.addEvent('click', '#avatar_upload_entry', (e) => {
      this.prevFileName = $('#mypage_avatar').getAttribute('src');

      this.handleAvatarUpload(e);
    });

    // 수정사항 서버 전송
    this.addEvent('click', '#edit_submit', async (e) => {
      await this.editSubmit(e);
      new HistoryTable($('#MyPage_info__history'), {
        id: this.props.user_id,
        name: this.props.username,
      });
    });

    // 엔터 시 수정사항 서버 전송
    this.addEvent('keydown', '#nickname_upload', async (e) => {
      if (e.key === 'Enter') {
        if (e.isComposing) return;
        await this.editSubmit(e);
        new HistoryTable($('#MyPage_info__history'), {
          id: this.props.user_id,
          name: this.props.username,
        });
      }
    });
  }

  handleAvatarUpload(e) {
    $('#avatar_upload').click();
    $('#avatar_upload').addEventListener('change', (e) => {
      const maxSize = 1024 * 1024;

      const file = e.target.files[0];

      if (file.size > maxSize) {
        alert('1MB 이하의 파일만 업로드 가능합니다.');
        return;
      }

      const reader = new FileReader();

      reader.readAsDataURL(file);

      reader.onload = (e) => {
        this.newFileName = e.target.result;

        $('#edit_modal_avatar').setAttribute('src', e.target.result);
      };
    });
  }

  async editSubmit(e) {
    const data = await this.handleModalSubmmit();

    if (data.status === 200 || data.status === 1001)
      e.target.closest('#Modal_overlay').remove();
    else if (data.status === 1002) {
      $('#duplicateWarning').textContent = '중복된 이름입니다.';
      $('#duplicateWarning').classList.remove('hidden');
    } else if (data.status === 1003) {
      $('#duplicateWarning').textContent = '공백문자만 포함할 수 없습니다.';
      $('#duplicateWarning').classList.remove('hidden');
    } else if (data.status === 1004) {
      $('#duplicateWarning').textContent =
        '영어 대소문자/숫자만 사용가능합니다.';
      $('#duplicateWarning').classList.remove('hidden');
    }
  }

  async handleModalSubmmit() {
    const data = await this.postEditInfo();

    if (data.status === 200) {
      const $profile = $('#app').querySelector('#MyPage_profile');

      if ($('#nickname_upload').value !== '')
        this.props.username = $('#nickname_upload').value;

      if (this.newFileName !== '') {
        this.prevFileName = this.newFileName;
      }
      this.props.picture = this.prevFileName;

      new Profile($profile, {
        state: this.props,
        icon1: '',
        icon2: '../../../public/edit.svg',
      });
    }

    return data;
  }

  async postEditInfo() {
    const newName = $('#nickname_upload').value;
    const newImage = $('#avatar_upload').files[0];

    const data = new FormData();

    data.append('newName', newName);
    data.append('picture', newImage);

    const config = {
      method: 'POST',
      url: '/mypage/editor',
      data: data,
    };

    try {
      const data = await apiController(config);

      return data;
    } catch (e) {
      return { status: e.data.code, data: e.data };
    }
  }
}
