import Component from '../../core/Component.js';
import Profile from './Profile.js';
import HistoryTable from './Table/HistoryTable.js';
import UserTable from './Table/UserTable.js';
import { tableNumbers } from '../../constant/tableNumbers.js';
import handleButtons from './handleButtons.js';
import { navigate } from '../../utils/navigate.js';
import apiController from '../../utils/apiController.js';
import { $ } from '../../utils/querySelector.js';
import { socket, checkHeartbeat, initWebSocket } from '../../utils/socket.js';
import Edit from './Modal/Edit.js';

let friendState = null;

export default class MyPage extends Component {
  constructor($target, props) {
    super($target, props);

    this.prevFileName = '';
    this.newFileName = '';
  }

  getSocketMessage() {
    socket.onmessage = (e) => {
      if (!checkHeartbeat(e)) {
        const data = JSON.parse(e.data);

        friendState = data;
      }
    };
  }

  async getMyPageInfo() {
    const config = {
      url: '/mypage',
    };
    const res = await apiController(config);
    const { data } = res;

    if (socket.readyState === WebSocket.OPEN) {
      socket.send(
        JSON.stringify({
          message: 'mypage',
          friends: data.friends,
        }),
      );
    }

    return data;
  }

  async setup() {
    initWebSocket();
    this.getSocketMessage();

    this.state = await this.getMyPageInfo();

    this.setEvent();
    this.render();
  }

  getPrevFilename() {
    this.prevFileName = $('#mypage_avatar').getAttribute('src');
  }

  mounted() {
    this.appendInfoWrapper();

    const $profile = this.$target.querySelector('#MyPage_profile');
    const $historyTable = this.$target.querySelector('#MyPage_info__history');
    const $friendTable = this.$target.querySelector('#MyPage_info__user_list');

    new Profile($profile, {
      state: this.state,
      icon1: '',
      icon2: '../../../public/edit.svg',
    });
    new HistoryTable($historyTable, {
      id: this.state.user_id,
      name: this.state.username,
    });
    new UserTable($friendTable, '친구 목록', tableNumbers.FRIEND, this.state);
    this.getPrevFilename();
  }

  appendInfoWrapper() {
    const $wrapper = document.createElement('div');
    $wrapper.id = 'MyPage_wrapper';
    this.$target.appendChild($wrapper);

    $wrapper.style.height = '100vh';

    $wrapper.innerHTML = `
    <div class="w-full h-full flex flex-col overflow-auto">
      <img id='goBackMyPage' src="../../../public/eva--arrow-back-fill.svg" alt="close" class='h-8 absolute top-6 left-6 rounded-full p-1 hover:shadow-md cursor-pointer'/>
      <div class="w-[calc(100% - 400px)] h-[870px] px-[100px] pb-[50px] min-w-[800px] max-w-[1200px] flex flex-col  m-auto">
          <div id="MyPage_profile_container">
            <div id="MyPage_profile"></div>
          </div>
          <div id="MyPage_info">
            <div id="MyPage_info__history"></div>
            <div id="MyPage_info__user_list"></div>
        </div>
      </div>
    </div>`;

    this.addEvent('click', '#goBackMyPage', (e) => {
      navigate('/');
      // new Home($('#app'));
    });
  }

  setEvent() {
    if (this.$target.classList.contains('MyPageEvents')) return;
    this.$target.classList.add('MyPageEvents');

    // 프로필 수정 모달 열기
    this.addEvent('click', '#edit_modal_open', (e) => {
      this.handleEdit(e.target);
    });

    this.$target.addEventListener('click', this.handleButton.bind(this));

    this.$target.addEventListener('keydown', async (e) => {
      if (e.key === 'Enter') {
        if (e.target.id === 'addFriendInListFriendName') {
          if (e.isComposing) return;
          handleButtons(this.$target, this.state, $('#addFrinedInListSubmit'));
        }
      }
    });
  }

  handleEdit(state) {
    const modal = document.createElement('div');
    modal.id = 'Modal_overlay';

    this.$target.appendChild(modal);

    new Edit(modal, this.state);

    $('#nickname_upload').focus();
  }

  async editSubmit(e) {
    const data = await this.handleModalSubmmit();

    if (data.status === 200 || data.status === 1001)
      e.target.closest('#Modal_overlay').remove();
    else if (data.status === 1002) {
      $('#duplicateWarning').textContent = '중복된 이름입니다.';
      $('#duplicateWarning').classList.remove('hidden');
    } else if (data.status === 1003) {
      $('#duplicateWarning').textContent = '공백문자만 포함할 수 없습니다.';
      $('#duplicateWarning').classList.remove('hidden');
    } else if (data.status === 1004) {
      $('#duplicateWarning').textContent =
        '영어 대소문자/숫자만 사용가능합니다.';
      $('#duplicateWarning').classList.remove('hidden');
    }
  }

  async handleModalSubmmit() {
    const data = await this.postEditInfo();

    if (data.status === 200) {
      const $profile = this.$target.querySelector('#MyPage_profile');

      if ($('#nickname_upload').value !== '')
        this.state.username = $('#nickname_upload').value;

      if (this.newFileName !== '') {
        this.prevFileName = this.newFileName;
      }
      this.state.picture = this.prevFileName;

      new Profile($profile, {
        state: this.state,
        icon1: '',
        icon2: '../../../public/edit.svg',
      });
    }

    return data;
  }

  async postEditInfo() {
    const newName = $('#nickname_upload').value;
    const newImage = $('#avatar_upload').files[0];

    const data = new FormData();

    data.append('newName', newName);
    data.append('picture', newImage);

    const config = {
      method: 'POST',
      url: '/mypage/editor',
      data: data,
    };

    try {
      const data = await apiController(config);

      return data;
    } catch (e) {
      return { status: e.data.code, data: e.data };
    }
  }

  handleButton(event) {
    const button = event.target;

    if (
      $('#addFriendInListFriendName') &&
      event.target.id !== 'addFriendInListFriendName' &&
      event.target.id !== 'addFrinedInListSubmit'
    ) {
      $('#addFriendInListWrapper').innerHTML = `
        <td id="addFrinedInList" class="flex flex-row w-[100%] h-[100%] justify-center items-center text-center cursor-pointer group">
          <img src="/public/plus.svg" id="addFriendInListIcon" class="icon_plus flex" id="icon_plus" alt="plus"></img>
          <span id="addFriendInListText" class="flex ml-[4px] font-semibold text-[#8090A8] group-hover:font-bold">친구 추가</span>
        </td>
        `;
    }

    handleButtons(this.$target, this.state, button);
  }
}

export { friendState };
