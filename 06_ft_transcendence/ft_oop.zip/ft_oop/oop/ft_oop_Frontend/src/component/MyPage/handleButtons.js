import { $ } from "../../utils/querySelector.js";
import UserTable from "./Table/UserTable.js";
import { tableNumbers } from "../../constant/tableNumbers.js";
import apiController from "../../utils/apiController.js";
import Alert from "./Modal/Alert.js";
import MyPage from "./MyPage.js";

export default async function handleButtons($target, state, button) {
  // 확인 모달 닫기
  if (button.id === "modal_close") {
    button.closest("#Modal_overlay").remove();

    const table = $("#Friend_table");

    if (table) {
      new UserTable(table, "친구 목록", tableNumbers.FRIEND, state);
    } else {
      const table = $("#Block_table");

      new UserTable(table, "차단 목록", tableNumbers.BLOCK, state);
    }
    // 목록에서 친구 추가
  } else if (
    button.id === "addFrinedInList" ||
    button.id === "addFriendInListIcon" ||
    button.id === "addFriendInListText"
  ) {
    const wrapper = $("#addFriendInListWrapper");

    wrapper.innerHTML = addFriendInList();
    $("#addFriendInListFriendName").focus();
  } else if (button.id === "addFrinedInListSubmit") {
    addFriendInListSubmit($target, state, button);
  }
}

async function addFriendInListSubmit($target, state, button) {
  const friendName = $("#addFriendInListFriendName").value;

  const config = {
    method: "POST",
    url: "/friend/add",
    data: {
      friend: friendName,
    },
  };

  try {
    const res = await apiController(config);

    if (res.status === 200) {
      const table = $("#Friend_table");

      new MyPage($("#app"));
    }
  } catch (e) {
    $("#addFriendInListFriendName").blur();

    const modal = document.createElement("div");
    modal.id = "Modal_overlay";

    $target.appendChild(modal);

    if (e.data.code === 2000) {
      new Alert(modal, { message: "차단된 사용자입니다." });
    } else if (e.data.code === 2001) {
      new Alert(modal, { message: "이미 친구입니다." });
    } else if (e.data.code === 2002) {
      new Alert(modal, { message: "공백은 쫌..." });
    } else {
      new Alert(modal, { message: "존재하지 않는 친구입니다." });
    }

    $("#addFriendInListWrapper").innerHTML = `
      <td id="addFrinedInList" class="flex flex-row w-[100%] h-[100%] justify-center items-center text-center cursor-pointer group">
        <img src="/public/plus.svg" id="addFriendInListIcon" class="icon_plus flex" id="icon_plus" alt="plus"></img>
        <span id="addFriendInListText" class="flex ml-[4px] font-semibold text-[#8090A8] group-hover:font-bold">친구 추가</span>
      </td>
    `;
  }
}

function addFriendInList() {
  return `
    <div class="input-group mb-3 my-auto ml-[20px] mr-[10px] flex">
      <input id="addFriendInListFriendName" type="text" class="form-control" placeholder="친구 이름" aria-label="친구 이름" aria-describedby="button-addon2" maxlength="15">
      <button id="addFrinedInListSubmit" class="w-[80px] btn btn-primary" type="button" id="button-addon2">추가</button>
    </div>
  `;
}
