import Component from '../../core/Component.js';

export default class TournamentInfo extends Component {
  template() {
    if (this.props.picture === undefined)
      this.props.picture = '../../../public/default-picture.png';
    return `
        <div class="w-[100px] h-[100px] rounded-full mx-auto overflow-hidden bg-gray-300 shadow-xl">
            <img class="object-cover w-full h-full" src=${this.props.picture}>
        </div>
        <p class="text-center">${this.props.name}</p>
    `;
  }
}
