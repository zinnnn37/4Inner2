import Component from "../../core/Component.js";
import { $ } from "../../utils/querySelector.js";
import GameScreen from "./GameScreen.js";
import { navigate } from "../../utils/navigate.js";
import PongGame from "./PongGame.js";
import { initWebSocket } from "../../utils/socket.js";
import Alert from "../MyPage/Modal/Alert.js";
import apiController from "../../utils/apiController.js";
import GamePicture from "./GamePicture.js";
import RoomList from "../RoomList/RoomList.js";

let user_number = 0;
let picture1 = undefined;
let picture2 = undefined;

export default class GameRoom extends Component {
  constructor($target, props, gamemode, t_socket, name) {
    super($target, props);

    this.gamemode = gamemode;
    this.name = name;
    if (t_socket !== undefined) this.t_socket = t_socket;
    this.beforeUnloadHandler = this.beforeUnloadHandler.bind(this);
  }

  setup() {
    history.pushState(null, null, `/game-room`);
    this.user1_ready = false;
    this.user2_ready = false;
    initWebSocket();
    this.initGameSocket();
    this.setEvent();
    this.render();
  }

  mounted() {
    this.appendInfoWrapper();
    const $gameScreenContainer = $("#gameScreenContainer");
    new GameScreen($gameScreenContainer, {
      user1: 0,
      user2: 0,
      picture1: picture1,
      picture2: picture2,
    });
    this.startGame();
  }

  appendInfoWrapper() {
    const $wrapper = document.createElement("div");
    $wrapper.id = "GameRoom_wrapper";
    this.$target.appendChild($wrapper);

    $wrapper.style.height = "100vh";

    $wrapper.innerHTML = `
      <div class="w-full h-full flex">
      <img id='goBackGame' src="../../../public/eva--arrow-back-fill.svg" alt="close" class='h-8 absolute top-6 left-6 rounded-full p-1 hover:shadow-md cursor-pointer'/>
        <div class="w-[1489px] h-[1117px] m-auto">
          <div class="w-full h-[100px]"></div>
          <div id="pongGameWrapper" class="w-full h-[917px] flex">
            <div id="gameScreenContainer" class="w-full h-full overflow-hidden m-auto bg-white rounded-lg shadow-2xl"></div>
          </div>
          <div class="w-full h-[100px] grid place-items-center">
            <button id = "game_ready" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 border border-blue-700 rounded">준비</button>
          </div>
        </div>
      </div>`;

    this.addEvent("click", "#goBackGame", async (e) => {
      window.removeEventListener("beforeunload", this.beforeUnloadHandler);
      // 소켓 닫기

      this.exitRoom();

      user_number = 0;
      navigate("/room-list");
    });
  }

  initGameSocket() {
    if (!this.game_sock) {
      this.game_sock = new WebSocket(
        "wss://" +
          window.location.host +
          ":443" +
          "/ws/main/game/" +
          this.props +
          "/"
      );
    }

    this.game_sock.onmessage = async (event) => {
      let message = JSON.parse(event.data);
      switch (message.type) {
        case "username": {
          if (this.name !== undefined) {
            user_number = this.name === message.message.host_name ? 1 : 2;
          } else {
            if (user_number === 0) {
              user_number = message.message.guests.length + 1;
            }
          }
          new GamePicture($("#gamePicture1"), message.message.host_picture);
          if (message.message.guests.length !== 0) {
            new GamePicture(
              $("#gamePicture2"),
              message.message.guests[0].guest_picture
            );
          } else new GamePicture($("#gamePicture2"), undefined);
          break;
        }
        case "ready": {
          if (message.user_number == 1) {
            this.user1_ready = true;
          } else if (message.user_number == 2) {
            this.user2_ready = true;
          }
          if (user_number == 1 && this.user1_ready && this.user2_ready) {
            this.game_sock.send(
              JSON.stringify({
                type: "start",
              })
            );
          }
          break;
        }
        case "start": {
          const game = new PongGame(
            $("#pongGameWrapper"),
            this.game_sock,
            user_number,
            this.user_name,
            this.props,
            this.gamemode,
            this.t_socket
          );
          game.pong();
          user_number = 0;
          break;
        }
        case "disconnect": {
          window.removeEventListener("beforeunload", this.beforeUnloadHandler);

          const modal = document.createElement("div");
          modal.id = "Modal_overlay";
          $("#app").appendChild(modal);

          new Alert(modal, {
            message: "호스트가 나갔습니다. 게임이 종료됩니다.",
            path: "/room-list",
          });
          this.game_sock.close();
          user_number = 0;
          break;
        }
      }
    };
  }

  startGame() {
    const startbutton = document.getElementById("game_ready");
    startbutton.addEventListener("click", () => {
      this.game_sock.send(
        JSON.stringify({
          type: "ready",
          user_num: user_number,
        })
      );
      startbutton.classList.add("hidden");
    });
  }

  async exitRoom() {
    const config = {
      url: `/game/exit`,
      method: "POST",
      data: {
        roomID: this.props,
      },
    };

    this.game_sock.close();

    const res = await apiController(config);
  }

  beforeUnloadHandler(e) {
    e.preventDefault();
    this.exitRoom();
    e.returnValue = "";
  }
}
