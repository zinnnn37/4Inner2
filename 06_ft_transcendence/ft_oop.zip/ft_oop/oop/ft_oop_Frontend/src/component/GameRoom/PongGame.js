import * as THREE from "https://unpkg.com/three/build/three.module.js";

import GameScore from "./GameScore.js";
import { $ } from "../../utils/querySelector.js";
import WinnerWrapper from "./WinnerWrapper.js";

export default class PongGame {
  constructor($target, socket, usernum, username, roomId, gamemode, t_socket) {
    this.socket = socket;
    this.usernum = usernum;
    this.username = username;
    this.roomId = roomId;
    this.gamemode = gamemode;
    this.t_socket = t_socket;
    this.winner = 0;

    this.user1 = {
      type: "user_update",
      id: "1",
      posY: 0,
      upPressed: false,
      downPressed: false,
      skill: false,
      skillpressed: false,
      skillpower: 0,
      score: 0,
    };

    this.user2 = {
      type: "user_update",
      id: "2",
      posY: 0,
      upPressed: false,
      downPressed: false,
      skill: false,
      skillpressed: false,
      skillpower: 0,
      score: 0,
    };

    this.ball_info = {
      type: "ball_update",
      radius: 5,
      posX: 0,
      posY: 0,
      dx: 4,
      dy: -3,
    };

    this.VIEW_ANGLE = 70;
    this.WIDTH = 1489;
    this.HEIGTH = 733.59;
    this.ASPECT = this.WIDTH / this.HEIGTH;
    this.NEAR = 0.1;
    this.FAR = 10000;
    this.container, this.renderer, this.camera, this.scene;
    (this.x_plane = 500),
      (this.y_plane = 300),
      (this.x_cube = 10),
      (this.y_cube = 50);
    this.plane, this.player_1, this.player_2, this.ball;

    if (this.usernum == "1") {
      document.addEventListener(
        "keydown",
        this.user1_keyDownHandler.bind(this),
        false
      );
      document.addEventListener(
        "keyup",
        this.user1_keyUpHandler.bind(this),
        false
      );
    } else if (this.usernum == "2") {
      document.addEventListener(
        "keydown",
        this.user2_keyDownHandler.bind(this),
        false
      );
      document.addEventListener(
        "keyup",
        this.user2_keyUpHandler.bind(this),
        false
      );
    }
  }

  useState() {
    const [gameInfo, setGameInfo] = useState("gameInfo", this.gameInfo);
    this.setGameInfo = setGameInfo;
  }

  setRenderer() {
    this.container = document.getElementById("myCanvas");
    this.renderer = new THREE.WebGLRenderer({ canvas: this.container });
    this.renderer.setSize(this.WIDTH, this.HEIGTH);
    this.renderer.setClearColor("#9ca3af");
  }

  user1_keyDownHandler(e, user1) {
    if (e.keyCode == 40) {
      this.user1.downPressed = true;
    } else if (e.keyCode == 38) {
      this.user1.upPressed = true;
    } else if (e.keyCode == 13) {
      this.user1.skillpressed = true;
    }
  }

  user1_keyUpHandler(e) {
    if (e.keyCode == 40) {
      this.user1.downPressed = false;
    } else if (e.keyCode == 38) {
      this.user1.upPressed = false;
    } else if (e.keyCode == 13) {
      this.user1.skillpressed = false;
      this.user1.skillpower = 0;
    }
  }

  user2_keyDownHandler(e) {
    if (e.keyCode == 40) {
      this.user2.downPressed = true;
    } else if (e.keyCode == 38) {
      this.user2.upPressed = true;
    } else if (e.keyCode == 13) {
      this.user2.skillpressed = true;
    }
  }

  user2_keyUpHandler(e) {
    if (e.keyCode == 40) {
      this.user2.downPressed = false;
    } else if (e.keyCode == 38) {
      this.user2.upPressed = false;
    } else if (e.keyCode == 13) {
      this.user2.skillpressed = false;
      this.user2.skillpower = 0;
    }
  }

  setCamera() {
    this.camera = new THREE.PerspectiveCamera(
      this.VIEW_ANGLE,
      this.ASPECT,
      this.NEAR,
      this.FAR
    );
    this.camera.position.set(0, 0, 300);
  }

  setScene() {
    this.scene = new THREE.Scene();
  }

  setLights() {
    let light = new THREE.AmbientLight(0xffffff);
    this.scene.add(light);
  }

  setWorld() {
    // 필드
    var geometry = new THREE.BoxGeometry(this.x_plane, this.y_plane, 0.01);
    var material = new THREE.MeshPhongMaterial({ color: 0x2222ff });
    this.plane = new THREE.Mesh(geometry, material);
    this.scene.add(this.plane);

    // 중앙분리
    var geometry = new THREE.BoxGeometry(5, this.y_plane, 1);
    var material = new THREE.MeshBasicMaterial({ color: 0x888888 });
    var centerbar = new THREE.Mesh(geometry, material);
    this.scene.add(centerbar);

    // 데코 1
    var geometry = new THREE.BoxGeometry(this.x_plane + 10, 5, 5);
    var material = new THREE.MeshBasicMaterial({
      color: 0xcccccc,
      side: THREE.DoubleSide,
    });
    var dec2 = new THREE.Mesh(geometry, material);
    dec2.position.y = this.y_plane / 2 + 0.025;
    this.scene.add(dec2);

    // 데코 2
    var geometry = new THREE.BoxGeometry(this.x_plane + 10, 5, 5);
    var material = new THREE.MeshBasicMaterial({
      color: 0xcccccc,
      side: THREE.DoubleSide,
    });
    var dec3 = new THREE.Mesh(geometry, material);
    dec3.position.y = -this.y_plane / 2 - 0.025;
    this.scene.add(dec3);

    // player_1
    var geometry = new THREE.BoxGeometry(this.x_cube, this.y_cube, 10);
    var material = new THREE.MeshPhongMaterial({ color: 0xffd400 });
    this.player_1 = new THREE.Mesh(geometry, material);
    this.player_1.position.x = -this.x_plane / 2;
    this.player_1.position.y = this.user1.posY;
    this.scene.add(this.player_1);

    // player_2
    var geometry = new THREE.BoxGeometry(this.x_cube, this.y_cube, 10);
    var material = new THREE.MeshPhongMaterial({ color: 0xff0000 });
    this.player_2 = new THREE.Mesh(geometry, material);
    this.player_2.position.y = this.user1.posY;
    this.player_2.position.x = this.x_plane / 2;
    this.scene.add(this.player_2);

    // 공
    var geometry = new THREE.SphereGeometry(this.ball_info.radius, 32, 32);
    var material = new THREE.MeshPhongMaterial({ color: 0xffffff });
    this.ball = new THREE.Mesh(geometry, material);
    this.ball.position.z = 0.05;
    this.scene.add(this.ball);
  }

  playerMove() {
    if (this.usernum == "1") {
      if (
        this.user1.upPressed &&
        this.player_1.position.y + this.y_cube / 2 + 5 < this.y_plane / 2
      ) {
        this.user1.posY += 5;
        this.player_1.position.y = this.user1.posY;
        this.socket.send(JSON.stringify(this.user1));
      } else if (
        this.user1.downPressed &&
        this.player_1.position.y - this.y_cube / 2 - 5 > -this.y_plane / 2
      ) {
        this.user1.posY -= 5;
        this.player_1.position.y = this.user1.posY;
        this.socket.send(JSON.stringify(this.user1));
      }
      if (this.user1.skillpressed == true) {
        this.user1.skillpower++;
      }
    } else if (this.usernum == "2") {
      if (
        this.user2.upPressed &&
        this.player_2.position.y + this.y_cube / 2 + 5 < this.y_plane / 2
      ) {
        this.user2.posY += 5;
        this.player_2.position.y = this.user2.posY;
        this.socket.send(JSON.stringify(this.user2));
      } else if (
        this.user2.downPressed &&
        this.player_2.position.y - this.y_cube / 2 - 5 > -this.y_plane / 2
      ) {
        this.user2.posY -= 5;
        this.player_2.position.y = this.user2.posY;
        this.socket.send(JSON.stringify(this.user2));
      }
      if (this.user2.skillpressed == true) {
        this.user2.skillpower++;
      }
    }
  }

  opponentMove() {
    if (this.usernum == "1") {
      this.player_2.position.y = this.user2.posY;
    } else if (this.usernum == "2") {
      this.player_1.position.y = this.user1.posY;
    }
  }

  ballMove() {
    if (this.usernum == "1") {
      this.ball_info.posX += this.ball_info.dx;
      this.ball_info.posY += this.ball_info.dy;
      this.socket.send(JSON.stringify(this.ball_info));
      this.ball.position.x = this.ball_info.posX;
      this.ball.position.y = this.ball_info.posY;
      if (this.ball.position.y < -this.y_plane / 2 + this.ball_info.radius) {
        this.ball_info.dy = -this.ball_info.dy;
      } else if (
        this.ball.position.y >
        this.y_plane / 2 - this.ball_info.radius
      ) {
        this.ball_info.dy = -this.ball_info.dy;
      }
      if (
        this.ball_info.dx >= 0 &&
        this.ball.position.x + this.x_cube / 2 + this.ball_info.radius >=
          this.player_2.position.x &&
        this.ball.position.y >= this.player_2.position.y - this.y_cube / 2 &&
        this.ball.position.y <= this.player_2.position.y + this.y_cube / 2
      ) {
        this.ball_info.dx = this.user2.skill ? -8 : -4;
        this.user2.skillpower = 0;
        this.user2.skill = false;
        this.socket.send(JSON.stringify(this.user2));
      }
      if (
        this.ball_info.dx <= 0 &&
        this.ball.position.x - this.x_cube / 2 - this.ball_info.radius <=
          this.player_1.position.x &&
        this.ball.position.y >= this.player_1.position.y - this.y_cube / 2 &&
        this.ball.position.y <= this.player_1.position.y + this.y_cube / 2
      ) {
        this.ball_info.dx = this.user1.skill ? 8 : 4;
        this.user1.skillpower = 0;
        this.user1.skill = false;
        this.socket.send(JSON.stringify(this.user2));
      }
    } else if (this.usernum == "2") {
      if (this.ball.position.x > this.ball_info.posX) {
        this.user2.skill = false;
        this.user2.skillpower = 0;
        this.socket.send(JSON.stringify(this.user2));
      }
      this.ball.position.x = this.ball_info.posX;
      this.ball.position.y = this.ball_info.posY;
    }
  }

  rand(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
  }

  resetWorld() {
    this.ball_info.posX = 0;
    if (Math.abs(this.ball_info.dx) > 4) {
      this.ball_info.dx = (this.ball_info.dx * 4) / 8;
    }
    this.ball_info.posY = this.rand(-140, 140);
    new GameScore($("#gameScreenScore"), {
      user1: this.user1.score,
      user2: this.user2.score,
    });
    this.user1.skillpower = 0;
    this.user2.skillpower = 0;
    this.user1.skill = false;
    this.user2.skill = false;
  }

  winOrLose() {
    if (this.ball.position.x + this.ball_info.radius >= this.x_plane / 2) {
      this.user1.score++;
      if (this.user1.score >= 5) {
        if (this.usernum === 1) {
          if (this.gamemode === 1 || this.gamemode === 2) {
            this.socket.send(
              JSON.stringify({
                type: "tournamentWin",
              })
            );
          } else {
            this.winner = this.usernum;
            this.socket.send(
              JSON.stringify({
                type: "win",
              })
            );
          }
        }
      }
      this.resetWorld();
    }
    if (this.ball.position.x - this.ball_info.radius <= -this.x_plane / 2) {
      this.user2.score++;
      if (this.user2.score >= 5) {
        if (this.usernum === 2) {
          if (this.gamemode === 1 || this.gamemode === 2) {
            this.socket.send(
              JSON.stringify({
                type: "tournamentWin",
              })
            );
          } else {
            this.winner = this.usernum;
            this.socket.send(
              JSON.stringify({
                type: "win",
              })
            );
          }
        }
      }
      this.resetWorld();
    }
  }

  setSocketEvent() {
    this.socket.onmessage = function (event) {
      let message = JSON.parse(event.data);

      switch (message.type) {
        case "user_update":
          {
            if (message.user == "1") {
              this.user1.posY = message.posY;
              this.user1.skill = message.skill;
            } else if (message.user == "2") {
              this.user2.posY = message.posY;
              this.user2.skill = message.skill;
            }
          }
          break;
        case "ball_update":
          {
            if (this.usernum == "2") {
              this.ball_info.posX = message.posX;
              this.ball_info.posY = message.posY;
            }
          }
          break;
        case "end_game": {
          cancelAnimationFrame(this.req);
          this.renderer.clear();

          if (this.user1.score >= 5) {
            if (this.usernum === 1 && this.gamemode === 1) {
              this.t_socket.send(
                JSON.stringify({
                  type: "winner",
                  roomId: this.roomId,
                })
              );
              this.socket.close();
            } else if (this.usernum === 1 && this.gamemode === 2) {
              this.t_socket.send(
                JSON.stringify({
                  type: "finalWinner",
                  roomId: this.roomId,
                })
              );
              this.socket.close();
            }
          }
          if (this.user2.score >= 5) {
            if (this.usernum === 2 && this.gamemode === 1) {
              this.t_socket.send(
                JSON.stringify({
                  type: "winner",
                  roomId: this.roomId,
                })
              );
              this.socket.close();
            } else if (this.usernum === 2 && this.gamemode === 2) {
              this.t_socket.send(
                JSON.stringify({
                  type: "finalWinner",
                  roomId: this.roomId,
                })
              );
              this.socket.close();
            }
          }
          this.resetWorld();
          break;
        }
        case "exit": {
          const modal = document.createElement("div");
          modal.id = "winnerModal";
          $("#app").appendChild(modal);

          new WinnerWrapper($("#winnerModal"), {
            winner: message.winner,
            picture: message.picture,
            roomId: this.roomId,
          });
          // }
          break;
        }
      }
    }.bind(this);
  }

  start() {
    this.setRenderer();
    this.setCamera();
    this.setScene();
    this.setLights();
    this.setWorld();
    this.setSocketEvent();
  }

  skill() {
    if (this.usernum == 1) {
      if (this.user1.skillpower >= 40) {
        this.user1.skill = true;
        this.socket.send(JSON.stringify(this.user1));
      } else {
        this.user1.skill = false;
        this.socket.send(JSON.stringify(this.user1));
      }
    } else if (this.usernum == 2) {
      if (this.user2.skillpower >= 40) {
        this.user2.skill = true;
        this.socket.send(JSON.stringify(this.user2));
      } else {
        this.user2.skill = false;
        this.socket.send(JSON.stringify(this.user2));
      }
    }
    if (this.user1.skill == true) {
      this.player_1.material.color.setHex(0x000000);
    } else {
      this.player_1.material.color.setHex(0xffd400);
    }
    if (this.user2.skill == true) {
      this.player_2.material.color.setHex(0xffffff);
    } else {
      this.player_2.material.color.setHex(0xff0000);
    }
  }

  animate() {
    this.req = requestAnimationFrame(this.animate.bind(this));
    this.playerMove();
    this.ballMove();
    this.opponentMove();
    this.winOrLose();
    this.skill();
    this.renderer.render(this.scene, this.camera);
  }

  init() {
    this.container = document.getElementById("myCanvas");

    this.renderer = new THREE.WebGLRenderer({ canvas: this.container });
    this.renderer.setSize(this.WIDTH, this.HEIGTH);
    this.renderer.setClearColor(0x808080);
    this.setScene();
    this.setCamera();
    this.setLights();
    this.renderer.render(this.scene, this.camera);
  }

  pong() {
    this.init();
    this.start();
    this.animate();
  }
}
