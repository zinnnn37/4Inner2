import Component from '../../core/Component.js';
import { $ } from '../../utils/querySelector.js';
import Loading from '../Loading.js';
import Winner from './Winner.js';

export default class WinnerWrapper extends Component {
  setup() {
    this.render();
    this.loading();
  }

  template() {
    return `
      <div id="background" class="fixed w-full h-full bg-white opacity-20">
      </div>
    `;
  }

  loading() {
    const modal = document.createElement('div');
    this.$target.appendChild(modal);

    new Loading(modal);
    new Winner($('#Loading'), this.props);
  }
}
