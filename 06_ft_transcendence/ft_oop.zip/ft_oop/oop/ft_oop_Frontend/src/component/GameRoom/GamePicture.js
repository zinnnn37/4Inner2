import Component from '../../core/Component.js';

export default class GamePicture extends Component {
  template() {
    if (this.props === undefined)
      this.props = '../../../public/default-picture.png';
    return `
        <img class="object-cover w-full h-full" src=${this.props}>
    `;
  }
}
