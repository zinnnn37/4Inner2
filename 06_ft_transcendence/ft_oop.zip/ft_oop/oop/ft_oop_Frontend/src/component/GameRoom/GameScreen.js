import Component from '../../core/Component.js';
import { $ } from '../../utils/querySelector.js';
import GameScore from './GameScore.js';

export default class GameScreen extends Component {
  template() {
    return `
      <div class="w-full h-1/5">
        <div id="gameScreenInfo" class="h-full w-[90vh] flex justify-center items-center m-auto bg-white">
          <div id="gamePicture1" class="w-[80px] h-[80px] mr-[40px] rounded-full overflow-hidden shadow-2xl"></div>
          <div id="gameScreenScore" class="h-full w-[60vh] overflow-hidden m-auto flex justify-center items-center bg-white"></div>
          <div id="gamePicture2" class="w-[80px] h-[80px] ml-[40px] rounded-full overflow-hidden shadow-2xl">
          </div>
        </div>
      </div>
      <div id="pongScene" class="w-full h-4/5">
        <canvas id="myCanvas" class="w-full h-full bg-gray-400">준비버튼을 눌러주세요</canvas>
      </div>
    `;
  }

  mounted() {
    new GameScore($('#gameScreenScore'), this.props);
  }
}
