import Component from '../../core/Component.js';
import RoomList from '../RoomList/RoomList.js';
import { $ } from '../../utils/querySelector.js';
import apiController from '../../utils/apiController.js';

export default class Winner extends Component {
  template() {
    return `
      <img id='close' src="../../../public/eva--close-fill.svg" alt="close" class='h-[50px] absolute top-6 right-6 rounded-full p-1 hover:shadow-md cursor-pointer'/>
      <div class="w-full h-full flex flex-col justify-center items-center">
        <div class="relative w-[500px] h-[500px]">
          <div class="absolute w-[400px] h-[400px] rounded-full overflow-hidden
            z-10 top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2"
          >
            <img id='userAvatar' src="${this.props.picture}" alt="profile"
              class="w-full h-full object-cover"
            >
          </div>
          <img src="../../../public/crown.png" alt="crown"
            class="absolute w-full h-full object-cover
            top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2"
          >
        </div>
        <div class="font-bold text-6xl animate-bounce text-gray-800
          drop-shadow-md shadow-purple-900"
        >
          ${this.props.winner}
        </div>
      </div>
    `;
  }

  setEvent() {
    this.addEvent('click', '#close', async (e) => {
      if (this.props.roomId) {
        const config = {
          url: `/game/exit`,
          method: 'POST',
          data: {
            roomID: this.props.roomId,
          },
        };

        const res = await apiController(config);
      }

      new RoomList($('#app'));
    });
  }
}
