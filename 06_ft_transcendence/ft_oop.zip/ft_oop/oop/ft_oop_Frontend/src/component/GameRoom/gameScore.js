import Component from '../../core/Component.js';

export default class GameScore extends Component {
  template() {
    return `
      <p class="text-[50px] font-bold">${this.props.user1} : ${this.props.user2}</p>
    `;
  }
}
