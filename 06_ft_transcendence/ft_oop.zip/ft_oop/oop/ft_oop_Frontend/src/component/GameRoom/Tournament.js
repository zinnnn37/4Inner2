import Component from "../../core/Component.js";
import { navigate } from "../../utils/navigate.js";
import { initWebSocket } from "../../utils/socket.js";
import Alert from "../MyPage/Modal/Alert.js";
import RoomList from "../RoomList/RoomList.js";
import apiController from "../../utils/apiController.js";
import { $ } from "../../utils/querySelector.js";
import GameRoom from "./GameRoom.js";
import TournamentInfo from "./TournamentInfo.js";
import WinnerWrapper from "./WinnerWrapper.js";

let user_number = 0;

let final_user1 = undefined;
let final_user2 = undefined;
let room1 = undefined;
let room2 = undefined;

export default class Tournament extends Component {
  constructor($target, props) {
    super($target, props);
    this.roomId = this.props.id;
  }

  async setup() {
    this.state = await this.getUserInfo();
    // username 은 닉네임이다.
    this.username1 = undefined;
    this.username2 = undefined;
    this.username3 = undefined;
    this.username4 = undefined;
    this.picture1 = undefined;
    this.picture2 = undefined;
    this.picture3 = undefined;
    this.picture4 = undefined;

    this.finalUser = [];

    history.pushState(null, "", `/tournament`);
    initWebSocket();
    this.initTournamentSocket();
    this.render();
  }

  async getUserInfo() {
    const config = {
      url: "/main",
    };

    const res = await apiController(config);
    return res.data;
  }

  mounted() {
    this.appendInfoWrapper();
    this.initPicture();
    this.startGame();
  }

  appendInfoWrapper() {
    const $wrapper = document.createElement("div");
    $wrapper.id = "tournamentWrapper";
    this.$target.appendChild($wrapper);

    $wrapper.style.height = "100vh";

    $wrapper.innerHTML = `
      <div class="w-full h-full flex">
        <img id='goBackTour' src="../../../public/eva--arrow-back-fill.svg" alt="close" class='h-8 absolute top-6 left-6 rounded-full p-1 hover:shadow-md cursor-pointer'/>
        <div class="w-[1728px] h-[1117px] m-auto">
          <div class="w-full h-[100px] flex"></div>
          <div class="w-full h-[917px] flex">
            <div id="tournamentContainer" class="w-full h-full">
              <div class="w-full h-1/3 flex justify-center items-center bg-white">
                <div id="tournament1" class="w-full h-full"></div>
              </div>
              <div class="w-full h-1/3 flex justify-center items-center bg-white">
                <div id="tournament2-1" class="w-full h-full mx-40"></div>
                <div id="tournament2-2" class="w-full h-full mx-40"></div>
              </div>
              <div class="w-full h-1/3 flex justify-center items-center bg-white">
                <div id="tournament4-1" class="w-full h-full mx-20"></div>
                <div id="tournament4-2" class="w-full h-full mx-20"></div>
                <div id="tournament4-3" class="w-full h-full mx-20"></div>
                <div id="tournament4-4" class="w-full h-full mx-20"></div>
              </div> 
            </div>
          </div>
          <div class="w-full h-1/5 grid place-items-center">
            <button id = "tournament_ready" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 border border-blue-700 rounded">준비</button>
          </div>
        </div>
      </div>
    `;
    const handleClick = async (e) => {
      const goBackTourButton = document.querySelector("#goBackTour");
      if (goBackTourButton) {
        const config = {
          url: `/game/exit`,
          method: "POST",
          data: {
            roomID: this.roomId,
          },
        };
        // 소켓 닫기
        this.tournament_sock.close();
        const res = await apiController(config);
        navigate("/room-list");
        // 이벤트 제거
        goBackTourButton.removeEventListener("click", handleClick);
      }
    };
    const goBackTourButton = document.querySelector("#goBackTour");
    if (goBackTourButton) {
      goBackTourButton.addEventListener("click", handleClick);
    }
  }

  initPicture() {
    new TournamentInfo($("#tournament4-1"), {
      name: "",
      picture: undefined,
    });
    new TournamentInfo($("#tournament4-2"), {
      name: "",
      picture: undefined,
    });
    new TournamentInfo($("#tournament4-3"), {
      name: "",
      picture: undefined,
    });
    new TournamentInfo($("#tournament4-4"), {
      name: "",
      picture: undefined,
    });
    new TournamentInfo($("#tournament2-1"), {
      name: "",
      picture: undefined,
    });
    new TournamentInfo($("#tournament2-2"), {
      name: "",
      picture: undefined,
    });
    new TournamentInfo($("#tournament1"), {
      name: "",
      picture: undefined,
    });
  }

  setFirstPicture(data) {
    const { host_name, host_picture, guests } = data;

    new TournamentInfo($("#tournament4-1"), {
      name: host_name,
      picture: host_picture,
    });

    for (let i = 0; i < guests.length; i++) {
      const { guest_name, guest_picture } = guests[i];

      this[`username${i + 2}`] = guest_name;
      this[`picture${i + 2}`] = guest_picture;

      new TournamentInfo($(`#tournament4-${i + 2}`), {
        name: guest_name,
        picture: guest_picture,
      });
    }
    for (let i = guests.length; i < 3; i++) {
      new TournamentInfo($(`#tournament4-${i + 2}`), {
        name: "",
        picture: undefined,
      });
    }
    this.username1 = host_name;
    this.picture1 = host_picture;
  }

  findGuestIndex(guests) {
    for (let i = 0; i < guests.length; i++) {
      if (guests[i].guest_name === this.props.nickName) {
        return i + 2;
      }
    }
  }

  selectNumber(host, guests) {
    if (host === this.props.nickName) {
      return 1;
    }

    return this.findGuestIndex(guests);
  }

  initTournamentSocket() {
    if (!this.tournament_sock) {
      this.tournament_sock = new WebSocket(
        "wss://" +
          window.location.host +
          ":443" +
          "/ws/main/tournament/" +
          this.roomId +
          "/"
      );
    }

    this.tournament_sock.onmessage = async (event) => {
      let message = JSON.parse(event.data);

      switch (message.type) {
        case "username": {
          if (user_number == 0) {
            user_number = this.selectNumber(
              message.message.host_name,
              message.message.guests
            );
          }

          this.setFirstPicture(message.message);
          break;
        }
        case "ready": {
          if (message.user_number == 1) {
            this.user1_ready = true;
          } else if (message.user_number == 2) {
            this.user2_ready = true;
          } else if (message.user_number == 3) {
            this.user3_ready = true;
          } else if (message.user_number == 4) {
            this.user4_ready = true;
          }
          if (
            user_number == 1 &&
            this.user1_ready &&
            this.user2_ready &&
            this.user3_ready &&
            this.user4_ready
          ) {
            this.tournament_sock.send(
              JSON.stringify({
                type: "start",
                host1: this.username1,
                host2: this.username3,
              })
            );
          }
          break;
        }
        case "finalReady": {
          this.finalUser.push(message.user_number);
          if (message.user_number == user_number) {
            this[`user${user_number}_ready`] = true;
          }

          if (this.finalUser.length === 2) {
            const finalHost =
              this.finalUser[0] < this.finalUser[1]
                ? this.finalUser[0]
                : this.finalUser[1];

            if (finalHost === user_number) {
              this.tournament_sock.send(
                JSON.stringify({
                  type: "finalStart",
                })
              );
            }
          }

          break;
        }
        case "start": {
          room1 = message.room1;
          room2 = message.room2;
          const config = {
            url: `/game/dual/${
              user_number === 2 ? message.room1 : message.room2
            }`,
            params: {
              password: "",
            },
          };

          const tournamentWrapper = $("#tournamentWrapper");
          const gameWrapper = document.createElement("div");
          gameWrapper.id = "GameWrapper";
          $("#app").insertBefore(gameWrapper, tournamentWrapper);

          if (user_number === 1) {
            new GameRoom(gameWrapper, message.room1, 1, this.tournament_sock);
          }
          this.sleep(300);
          if (user_number === 2) {
            const res = await apiController(config);

            new GameRoom(gameWrapper, message.room1, 1, this.tournament_sock);
          }
          this.sleep(300);
          if (user_number === 3) {
            new GameRoom(gameWrapper, message.room2, 1, this.tournament_sock);
          }
          this.sleep(300);
          if (user_number === 4) {
            const res = await apiController(config);

            new GameRoom(gameWrapper, message.room2, 1, this.tournament_sock);
          }
          break;
        }
        case "finalStart": {
          const config = {
            url: `/game/dual/${message.roomId}`,
            params: {
              password: "",
            },
          };

          // guest
          for (let i = 3; i < 5; i++) {
            if (user_number === i && this[`user${i}_ready`] === true) {
              const res = await apiController(config);
            }
          }

          // game modal 띄우기
          for (let i = 1; i < 5; i++) {
            if (user_number === i && this[`user${i}_ready`] === true) {
              const tournamentWrapper = $("#tournamentWrapper");
              const gameWrapper = document.createElement("div");
              gameWrapper.id = "GameWrapper";
              $("#app").insertBefore(gameWrapper, tournamentWrapper);

              new GameRoom(
                gameWrapper,
                message.roomId,
                2,
                this.tournament_sock,
                this.state.username
              );
            }
          }
          break;
        }
        case "win": {
          this.tournament_sock.send(
            JSON.stringify({
              type: "isPresent",
              roomId1: room1,
              roomId2: room2,
            })
          );

          if (message.roomId == room1) {
            final_user1 = message.nickname;
            new TournamentInfo($("#tournament2-1"), {
              name: message.nickname,
              picture: message.picture,
            });
          } else if (message.roomId == room2) {
            final_user2 = message.nickname;
            new TournamentInfo($("#tournament2-2"), {
              name: message.nickname,
              picture: message.picture,
            });
          }
          const readyButton = $("#tournament_ready");
          readyButton.classList.add("invisible");
          if (
            (final_user1 !== undefined &&
              final_user1 === this.props.nickName) ||
            (final_user2 !== undefined && final_user2 === this.props.nickName)
          ) {
            readyButton.classList.remove("invisible");
          }

          break;
        }
        case "finalWinner": {
          new TournamentInfo($("#tournament1"), {
            name: message.nickname,
            picture: message.picture,
          });

          if ($("#GameWrapper")) $("#GameWrapper").remove();

          const modal = document.createElement("div");
          modal.id = "winnerModal";
          $("#app").appendChild(modal);

          this.tournament_sock.close();

          new WinnerWrapper($("#winnerModal"), {
            winner: message.nickname,
            picture: message.picture,
          });

          break;
        }
        case "disconnect": {
          new RoomList($("#app"));

          const modal = document.createElement("div");
          modal.id = "Modal_overlay";
          $("#app").appendChild(modal);

          new Alert(modal, {
            message: "호스트가 나갔습니다. 게임이 종료됩니다.",
          });

          this.tournament_sock.close();
          this.tournament_sock = null;

          break;
        }
        case "remove": {
          if ($("#GameWrapper")) $("#GameWrapper").remove();
          $("#tournament_ready").disabled = false;

          this.user1_ready = false;
          this.user2_ready = false;
          this.user3_ready = false;
          this.user4_ready = false;

          break;
        }
      }
    };
  }

  sleep(ms) {
    const wakeUpTime = Date.now() + ms;
    while (Date.now() < wakeUpTime) {}
  }

  startGame() {
    const startbutton = document.getElementById("tournament_ready");

    startbutton.addEventListener(
      "click",
      function () {
        if (startbutton.classList.contains("finalReady")) {
          this.tournament_sock.send(
            JSON.stringify({
              type: "finalReady",
              user_num: user_number,
            })
          );
          startbutton.disabled = true;
        } else {
          this.tournament_sock.send(
            JSON.stringify({
              type: "ready",
              user_num: user_number,
            })
          );
          startbutton.disabled = true;
          startbutton.classList.add("finalReady");
        }
      }.bind(this)
    );
  }
}
