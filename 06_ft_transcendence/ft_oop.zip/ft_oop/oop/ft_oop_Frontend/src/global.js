const BASE_IP = window.location.host;
const BASE_URL = `https://${BASE_IP}/api`;
const MAIN_WEBSOCKET = `wss://${BASE_IP}/ws/main/`;

export { BASE_URL, MAIN_WEBSOCKET, BASE_IP };
