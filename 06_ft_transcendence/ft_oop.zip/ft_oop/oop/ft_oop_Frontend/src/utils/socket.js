import { MAIN_WEBSOCKET } from '../global.js';

let socket = null;

function initWebSocket() {
  if (!socket) {
    socket = new WebSocket(MAIN_WEBSOCKET);
  }

  socket.onclose = (e) => {
    initWebSocket();
  };
}

function checkHeartbeat(e) {
  const data = JSON.parse(e.data);

  if (data.message === 'pong') {
    return true;
  }
  return false;
}

export { initWebSocket, checkHeartbeat, socket };
