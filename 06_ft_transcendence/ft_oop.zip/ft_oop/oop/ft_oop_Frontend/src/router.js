import { routes } from './constant/routeInfo.js';
import NotFound from './component/notfound.js';
import Login from './component/Login/Login.js';

function Router($container) {
  this.$container = $container;
  let currentPage = undefined;

  const findMatchedRoute = () =>
    routes.find((route) => route.path.test(location.pathname));

  const route = () => {
    currentPage = null;

    const TargetPage = localStorage.getItem('accessToken')
      ? findMatchedRoute()?.element || NotFound
      : Login;
    currentPage = new TargetPage(this.$container);
  };

  const init = () => {
    if (this.$container.classList.contains('routerEvent')) return;
    else {
      this.$container.classList.add('routerEvent');
      window.addEventListener('historychange', ({ detail }) => {
        const { to, isReplace, s } = detail;

        if (isReplace || to === location.pathname) {
          history.replaceState(null, '', to);
        } else {
          history.pushState(null, '', to);
        }

        route();
      });

      window.addEventListener('popstate', () => {
        route();
      });
    }
  };

  init();
  route();
}

export default Router;
