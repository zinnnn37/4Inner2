import Home from '../component/Home/Home.js';
import TwoFA from '../component/Login/2FA.js';
import Login from '../component/Login/Login.js';
import MyPage from '../component/MyPage/MyPage.js';
import RoomList from '../component/RoomList/RoomList.js';
import Loading from '../component/Loading.js';
import WinnerWrapper from '../component/GameRoom/WinnerWrapper.js';

export const routes = [
  { path: /^\/$/, element: Home },
  { path: /^\/login$/, element: Login },
  { path: /^\/mypage$/, element: MyPage },
  { path: /^\/room-list$/, element: RoomList },
  { path: /^\/game-room/, element: RoomList },
  // { path: /^\/winner/, element: WinnerWrapper },
  { path: /^\/tournament/, element: RoomList },
  { path: /^\/2FA$/, element: TwoFA },
  { path: /^\/loading$/, element: Loading },
  // { path: /^\/post\/[\w]+$/, element: Post },
  // { path: /^\/shop$/, element: Shop },
];
