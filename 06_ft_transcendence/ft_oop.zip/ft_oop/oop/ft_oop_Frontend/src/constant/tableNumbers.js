export const tableNumbers = {
  FRIEND: 1,
  BLOCK: 2,
};
