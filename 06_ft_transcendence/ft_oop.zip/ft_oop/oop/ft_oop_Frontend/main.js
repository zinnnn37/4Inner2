import App from './src/app.js';
import { $ } from './src/utils/querySelector.js';
import { render } from './src/utils/useState.js';

render(App, $('#app'));
